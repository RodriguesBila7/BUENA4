import React, { useState, useEffect } from 'react';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import useTranslation from './hooks/useTranslation';

const DEFAULT_SETTINGS = {
  nome_instituicao: 'Serviço Nacional de Investigação Criminal',
  sigla: 'SERNIC',
  logotipo: null, // Nulo por padrão. Será exibido o logotipo padrão do sistema
  cor_principal: '#1B365D',
  cor_secundaria: '#2D3748',
  cor_destaque: '#FFFFFF',
  modo_tema: 'light',
  data_atualizacao: new Date().toISOString(),
  usuario_responsavel: 'Sistema (Padrão)'
};

import { useAuth } from './contexts/AuthContext';
import useSecuritySettings from './hooks/useSecuritySettings';

export default function App() {
  const { user, login, logout, updateSessionActivity } = useAuth();
  const { policies } = useSecuritySettings();
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const { t, language, setLanguage } = useTranslation();

  // Carregar configurações do localStorage ao iniciar (simulação de carregamento do DB)
  useEffect(() => {
    const saved = localStorage.getItem('sernic_identity_settings');
    if (saved) {
      try {
        setSettings(JSON.parse(saved));
      } catch (e) {
        console.error("Erro ao carregar configurações salvas, usando padrão.", e);
        setSettings(DEFAULT_SETTINGS);
      }
    }
  }, []);

  // Aplicar cores e tema globalmente sempre que houver alteração
  useEffect(() => {
    // Injeção de variáveis CSS customizadas
    document.documentElement.style.setProperty('--color-primary', settings.cor_principal);
    document.documentElement.style.setProperty('--color-secondary', settings.cor_secundaria);
    document.documentElement.style.setProperty('--color-accent', settings.cor_destaque);
    
    // Injeção do modo de tema no html/root
    document.documentElement.setAttribute('data-theme', settings.modo_tema);
  }, [settings]);

  // Função para actualizar e salvar configurações (simulação de UPDATE SQL)
  const updateSettings = (newSettings) => {
    const updated = {
      ...newSettings,
      data_atualizacao: new Date().toISOString()
    };
    setSettings(updated);
    localStorage.setItem('sernic_identity_settings', JSON.stringify(updated));
  };

  // Função para restaurar configurações padrão (simulação de RESET SQL)
  const resetSettings = (adminUser) => {
    const resetValues = {
      ...DEFAULT_SETTINGS,
      data_atualizacao: new Date().toISOString(),
      usuario_responsavel: adminUser
    };
    setSettings(resetValues);
    localStorage.setItem('sernic_identity_settings', JSON.stringify(resetValues));
  };

  const handleLogin = (userData) => {
    login(userData);
    
    // Forçar a vista inicial e menus colapsados no novo login
    localStorage.setItem('sernic_active_tab', 'home');
    localStorage.setItem('sernic_expanded_menu', '');
    localStorage.setItem('sernic_expanded_submenu', '');
  };

  const handleLogout = () => {
    logout();
  };

  // Controlo de Inatividade e Expiração da Sessão
  useEffect(() => {
    const INACTIVITY_LIMIT_MS = (policies.sessionTimeoutMinutes || 15) * 60 * 1000;
    let inactivityTimer;

    const resetTimer = () => {
      if (user) {
        updateSessionActivity();
        clearTimeout(inactivityTimer);
        inactivityTimer = setTimeout(() => {
          handleLogout();
          alert('Sessão expirada por inatividade. Por favor, faça login novamente.');
        }, INACTIVITY_LIMIT_MS);
      }
    };

    const handleVisibilityChange = () => {
      if (!document.hidden && user) {
        const lastActivity = parseInt(localStorage.getItem('sernic_last_activity') || '0', 10);
        if (Date.now() - lastActivity > INACTIVITY_LIMIT_MS) {
          handleLogout();
          alert('Sessão expirada por inatividade. Por favor, faça login novamente.');
        } else {
          resetTimer();
        }
      }
    };

    if (user) {
      resetTimer();
      window.addEventListener('mousemove', resetTimer);
      window.addEventListener('keydown', resetTimer);
      window.addEventListener('click', resetTimer);
      window.addEventListener('scroll', resetTimer);
      document.addEventListener('visibilitychange', handleVisibilityChange);
    }

    return () => {
      clearTimeout(inactivityTimer);
      window.removeEventListener('mousemove', resetTimer);
      window.removeEventListener('keydown', resetTimer);
      window.removeEventListener('click', resetTimer);
      window.removeEventListener('scroll', resetTimer);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [user, policies.sessionTimeoutMinutes]);

  return (
    <>
      {user ? (
        <Dashboard 
          user={user} 
          settings={settings} 
          updateSettings={updateSettings} 
          resetSettings={resetSettings} 
          onLogout={handleLogout}
          t={t}
          language={language}
          setLanguage={setLanguage}
        />
      ) : (
        <Login 
          settings={settings} 
          onLogin={handleLogin}
          updateSettings={updateSettings}
          t={t}
          language={language}
          setLanguage={setLanguage}
        />
      )}
    </>
  );
}
