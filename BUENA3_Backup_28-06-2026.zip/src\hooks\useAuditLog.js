import { useState, useEffect } from 'react';

const STORAGE_KEY = 'sernic_audit_logs';

export default function useAuditLog() {
  const [logs, setLogs] = useState([]);

  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        setLogs(JSON.parse(saved));
      }
    } catch (e) {
      console.error("Erro ao carregar logs de auditoria", e);
    }
  }, []);

  const saveLogs = (newLogs) => {
    // Manter no máximo os últimos 2000 registos para não estourar o localStorage
    const limitedLogs = newLogs.slice(0, 2000);
    setLogs(limitedLogs);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(limitedLogs));
  };

  /**
   * Registar uma nova ação no sistema
   * @param {Object} user - Utilizador logado (nome, role)
   * @param {String} moduleName - Módulo onde a ação ocorreu (ex: "Funcionários")
   * @param {String} action - Ação executada (ex: "Criar", "Editar", "Login")
   * @param {String} details - Detalhes adicionais (ex: "Criou funcionário ID x")
   * @param {String} result - "Sucesso" ou "Falha"
   */
  const logAction = (user, moduleName, action, details, result = 'Sucesso') => {
    const now = new Date();
    
    // Simular IP, Browser e OS (em produção viria do request no backend)
    const ip = '192.168.1.' + Math.floor(Math.random() * 255);
    const browser = navigator.userAgent.includes('Chrome') ? 'Google Chrome' : 
                    navigator.userAgent.includes('Firefox') ? 'Mozilla Firefox' : 
                    navigator.userAgent.includes('Safari') ? 'Safari' : 'Outro';
    
    const os = navigator.platform || 'Windows';

    const newLog = {
      id: 'log_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
      username: user?.username || 'Sistema',
      role: user?.role || 'Sistema',
      date: now.toISOString().split('T')[0],
      time: now.toTimeString().split(' ')[0],
      timestamp: now.toISOString(),
      module: moduleName,
      action: action,
      details: details,
      ip: ip,
      device: os,
      browser: browser,
      result: result
    };

    setLogs(prev => {
      const updatedLogs = [newLog, ...prev];
      // Save synchronously to ensure critical logs aren't lost if page closes
      try {
        const limited = updatedLogs.slice(0, 2000);
        localStorage.setItem(STORAGE_KEY, JSON.stringify(limited));
        return limited;
      } catch (e) {
        return prev;
      }
    });
  };

  const getLogs = () => logs;

  return {
    logs,
    logAction,
    getLogs
  };
}
