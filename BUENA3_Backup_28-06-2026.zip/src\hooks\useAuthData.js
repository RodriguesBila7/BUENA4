import { useState, useEffect } from 'react';

const STORAGE_KEY_USERS = 'sernic_users';
const STORAGE_KEY_ROLES = 'sernic_roles';

const ALL_MODULES = [
  'Dashboard', 'Funcionarios', 'Estrutura Organizacional', 'Processo Disciplinar',
  'Formacao', 'Avaliacao de Desempenho', 'Ferias', 'Licencas', 'Transferencias',
  'Promocoes', 'Carreiras', 'Categorias', 'Relatorios', 'Configuracoes',
  'Utilizadores', 'Auditoria'
];

const DEFAULT_ROLES = [
  {
    id: 'super_admin',
    name: 'Super Administrador',
    description: 'Acesso total a todas as funcionalidades e configurações.',
    permissions: ALL_MODULES.reduce((acc, mod) => {
      acc[mod] = ['Visualizar', 'Criar', 'Editar', 'Eliminar', 'Validar', 'Exportar', 'Importar', 'Imprimir', 'Administrar'];
      return acc;
    }, {})
  },
  {
    id: 'hr_manager',
    name: 'Técnico de Recursos Humanos',
    description: 'Gestão completa do cadastro, sem acesso a auditoria e configurações de sistema.',
    permissions: ALL_MODULES.reduce((acc, mod) => {
      if (['Configuracoes', 'Auditoria', 'Utilizadores'].includes(mod)) {
        acc[mod] = [];
      } else {
        acc[mod] = ['Visualizar', 'Criar', 'Editar', 'Exportar', 'Imprimir'];
      }
      return acc;
    }, {})
  },
  {
    id: 'dept_head',
    name: 'Chefe de Departamento',
    description: 'Visualização e validação de processos apenas do seu departamento.',
    permissions: ALL_MODULES.reduce((acc, mod) => {
      acc[mod] = ['Visualizar', 'Validar', 'Exportar'];
      return acc;
    }, {})
  }
];

const DEFAULT_USERS = [
  {
    id: 'usr_admin',
    name: 'Administrador Principal',
    username: 'admin',
    email: 'admin@sistema.local',
    contact: '+258 84 000 0000',
    password: 'admin', // Demo only. Em produção usa-se hash.
    roleId: 'super_admin',
    status: 'Ativo',
    directorateId: null,
    departmentId: null,
    divisionId: null,
    sectionId: null,
    photo: '',
    failedAttempts: 0,
    lockedUntil: null,
    forcePasswordChange: false,
    createdAt: new Date().toISOString()
  }
];

export default function useAuthData() {
  const [users, setUsers] = useState([]);
  const [roles, setRoles] = useState([]);

  useEffect(() => {
    try {
      const savedRoles = localStorage.getItem(STORAGE_KEY_ROLES);
      if (savedRoles) {
        setRoles(JSON.parse(savedRoles));
      } else {
        setRoles(DEFAULT_ROLES);
        localStorage.setItem(STORAGE_KEY_ROLES, JSON.stringify(DEFAULT_ROLES));
      }

      const savedUsers = localStorage.getItem(STORAGE_KEY_USERS);
      if (savedUsers) {
        setUsers(JSON.parse(savedUsers));
      } else {
        setUsers(DEFAULT_USERS);
        localStorage.setItem(STORAGE_KEY_USERS, JSON.stringify(DEFAULT_USERS));
      }
    } catch (e) {
      console.error("Erro ao carregar dados de autenticação", e);
    }
  }, []);

  const saveUsers = (newUsers) => {
    setUsers(newUsers);
    localStorage.setItem(STORAGE_KEY_USERS, JSON.stringify(newUsers));
  };

  const saveRoles = (newRoles) => {
    setRoles(newRoles);
    localStorage.setItem(STORAGE_KEY_ROLES, JSON.stringify(newRoles));
  };

  // Funções de Gestão de Utilizadores
  const addUser = (userData) => {
    if (users.some(u => u.username === userData.username)) {
      return { success: false, error: 'O nome de utilizador já existe.' };
    }
    const newUser = {
      ...userData,
      id: 'usr_' + Date.now(),
      failedAttempts: 0,
      lockedUntil: null,
      createdAt: new Date().toISOString()
    };
    saveUsers([...users, newUser]);
    return { success: true, user: newUser };
  };

  const updateUser = (id, userData) => {
    const exists = users.some(u => u.username === userData.username && u.id !== id);
    if (exists) {
      return { success: false, error: 'O nome de utilizador já existe.' };
    }
    const updated = users.map(u => u.id === id ? { ...u, ...userData, updatedAt: new Date().toISOString() } : u);
    saveUsers(updated);
    return { success: true };
  };

  const deleteUser = (id) => {
    // Implementar Soft Delete ou bloqueio se houver histórico.
    // Para simplificar: mudar status para 'Inativo' em vez de apagar
    const updated = users.map(u => u.id === id ? { ...u, status: 'Inativo', deletedAt: new Date().toISOString() } : u);
    saveUsers(updated);
    return { success: true };
  };

  // Funções de Autenticação (Login Simulado)
  const authenticate = (username, password, policies) => {
    const user = users.find(u => u.username === username);
    if (!user) return { success: false, error: 'Credenciais inválidas.' };

    if (user.status === 'Inativo') {
      return { success: false, error: 'Esta conta encontra-se desativada.' };
    }

    if (user.status === 'Bloqueada' || (user.lockedUntil && new Date(user.lockedUntil) > new Date())) {
      return { success: false, error: 'A sua conta encontra-se bloqueada devido a várias tentativas falhadas. Tente mais tarde ou contacte o administrador.' };
    }

    if (user.password !== password) {
      // Regista falha e verifica bloqueio
      const newAttempts = (user.failedAttempts || 0) + 1;
      let updateFields = { failedAttempts: newAttempts };
      
      if (newAttempts >= policies.loginMaxAttempts) {
        updateFields.status = 'Bloqueada';
        const lockTime = new Date();
        lockTime.setMinutes(lockTime.getMinutes() + policies.loginLockoutMinutes);
        updateFields.lockedUntil = lockTime.toISOString();
      }
      updateUser(user.id, updateFields);
      
      return { success: false, error: 'Credenciais inválidas.' };
    }

    // Login com sucesso: limpa tentativas falhadas
    updateUser(user.id, { failedAttempts: 0, lockedUntil: null, status: 'Ativo' });

    // Encontrar o Role associado
    const role = roles.find(r => r.id === user.roleId) || null;
    
    // Retornar um token JWT simulado e os dados sanitizados
    const { password: _, ...sanitizedUser } = user;
    return { success: true, user: { ...sanitizedUser, roleDetails: role } };
  };

  // Gestão de Perfis (Roles)
  const addRole = (roleData) => {
    const newRole = { ...roleData, id: 'role_' + Date.now() };
    saveRoles([...roles, newRole]);
    return { success: true, role: newRole };
  };

  const updateRole = (id, roleData) => {
    saveRoles(roles.map(r => r.id === id ? { ...r, ...roleData } : r));
    return { success: true };
  };

  const deleteRole = (id) => {
    if (users.some(u => u.roleId === id)) {
      return { success: false, error: 'Não é possível eliminar um perfil que está associado a utilizadores.' };
    }
    saveRoles(roles.filter(r => r.id !== id));
    return { success: true };
  };

  return {
    users,
    roles,
    addUser,
    updateUser,
    deleteUser,
    authenticate,
    addRole,
    updateRole,
    deleteRole
  };
}
