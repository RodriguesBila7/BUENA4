import { useState, useEffect } from 'react';

const STORAGE_KEY = 'sernic_security_policies';

const DEFAULT_POLICIES = {
  // Password
  pwdMinLength: 8,
  pwdRequireUppercase: true,
  pwdRequireLowercase: true,
  pwdRequireNumbers: true,
  pwdRequireSpecial: true,
  pwdHistoryCount: 3,
  pwdExpiryDays: 90,
  pwdForceChangeFirstLogin: true,
  
  // Session
  sessionTimeoutMinutes: 15,
  sessionMaxSimultaneous: 1,
  
  // Login Security
  loginMaxAttempts: 3,
  loginLockoutMinutes: 15,
  loginTwoFactorAuth: false
};

export default function useSecuritySettings() {
  const [policies, setPolicies] = useState(DEFAULT_POLICIES);

  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        setPolicies({ ...DEFAULT_POLICIES, ...JSON.parse(saved) });
      } else {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_POLICIES));
      }
    } catch (e) {
      console.error("Erro ao carregar politicas de segurança", e);
    }
  }, []);

  const updatePolicies = (newPolicies) => {
    const updated = { ...policies, ...newPolicies };
    setPolicies(updated);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    return true;
  };

  /**
   * Validate a password against current policies
   */
  const validatePassword = (password) => {
    const errors = [];
    if (password.length < policies.pwdMinLength) {
      errors.push(`A palavra-passe deve ter no mínimo ${policies.pwdMinLength} caracteres.`);
    }
    if (policies.pwdRequireUppercase && !/[A-Z]/.test(password)) {
      errors.push('Deve conter pelo menos uma letra maiúscula.');
    }
    if (policies.pwdRequireLowercase && !/[a-z]/.test(password)) {
      errors.push('Deve conter pelo menos uma letra minúscula.');
    }
    if (policies.pwdRequireNumbers && !/[0-9]/.test(password)) {
      errors.push('Deve conter pelo menos um número.');
    }
    if (policies.pwdRequireSpecial && !/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/.test(password)) {
      errors.push('Deve conter pelo menos um caracter especial.');
    }
    return {
      isValid: errors.length === 0,
      errors
    };
  };

  return {
    policies,
    updatePolicies,
    validatePassword
  };
}
