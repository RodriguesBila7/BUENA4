import React, { useState } from 'react';

const MOCK_ACCOUNTS = [
  { id: 1, name: 'João Silva', username: 'jsilva', email: 'jsilva@sernic.gov.mz', role: 'Super Administrador', status: 'Ativo', lastLogin: '2026-06-28 14:30', department: 'DRH' },
  { id: 2, name: 'Maria Santos', username: 'msantos', email: 'msantos@sernic.gov.mz', role: 'Gestor', status: 'Ativo', lastLogin: '2026-06-27 09:15', department: 'Operações' },
  { id: 3, name: 'Rui Costa', username: 'rcosta', email: 'rcosta@sernic.gov.mz', role: 'Utilizador Comum', status: 'Bloqueado', lastLogin: '2026-06-20 11:00', department: 'Finanças' },
];

const styles = {
  header: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px', flexWrap: 'wrap', gap: '15px' },
  searchBar: { flex: 1, minWidth: '200px', padding: '10px 14px', borderRadius: '6px', border: '1px solid var(--color-border)', backgroundColor: 'var(--color-bg-base)', color: 'var(--color-text-base)' },
  button: { padding: '10px 16px', backgroundColor: 'var(--color-success)', color: '#fff', border: 'none', borderRadius: '6px', cursor: 'pointer', fontWeight: 'bold' },
  tableContainer: { overflowX: 'auto', backgroundColor: 'var(--color-bg-card)', borderRadius: '8px', border: '1px solid var(--color-border)' },
  table: { width: '100%', borderCollapse: 'collapse', fontSize: '13px' },
  th: { textAlign: 'left', padding: '12px 16px', borderBottom: '2px solid var(--color-border)', color: 'var(--color-text-muted)', backgroundColor: 'var(--color-bg-base)', textTransform: 'uppercase' },
  td: { padding: '12px 16px', borderBottom: '1px solid var(--color-border)', color: 'var(--color-text-base)' },
  badge: (status) => ({
    padding: '4px 8px', borderRadius: '12px', fontSize: '11px', fontWeight: 'bold',
    backgroundColor: status === 'Ativo' ? 'rgba(16, 185, 129, 0.1)' : 'rgba(245, 158, 11, 0.1)',
    color: status === 'Ativo' ? 'var(--color-success)' : 'var(--color-warning)'
  }),
  actionBtn: { padding: '4px 8px', fontSize: '12px', border: '1px solid var(--color-border)', borderRadius: '4px', cursor: 'pointer', backgroundColor: 'transparent', color: 'var(--color-text-base)' },
  empty: { textAlign: 'center', padding: '30px', color: 'var(--color-text-muted)', fontStyle: 'italic' },
  actions: { display: 'flex', gap: '10px' }
};

export default function AccountList({ t }) {
  const [searchTerm, setSearchTerm] = useState('');

  const filtered = MOCK_ACCOUNTS.filter(acc => 
    acc.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    acc.username.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="animate-fade-in">
      <div style={styles.header}>
        <input 
          type="text" 
          placeholder="Pesquisar por nome ou username..." 
          style={styles.searchBar}
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <div style={{ display: 'flex', gap: '10px' }}>
          <button style={styles.button}>Exportar Excel</button>
          <button style={{...styles.button, backgroundColor: 'var(--color-primary)'}}>+ Nova Conta</button>
        </div>
      </div>

      <div style={styles.tableContainer}>
        <table style={styles.table}>
          <thead>
          <tr>
            <th style={styles.th}>Utilizador</th>
            <th style={styles.th}>Email</th>
            <th style={styles.th}>Perfil</th>
            <th style={styles.th}>Departamento</th>
            <th style={styles.th}>Último Login</th>
            <th style={styles.th}>Estado</th>
            <th style={styles.th}>Ações</th>
          </tr>
        </thead>
        <tbody>
          {filtered.map(acc => (
            <tr key={acc.id}>
              <td style={styles.td}>
                <div style={{ fontWeight: 'bold' }}>{acc.name}</div>
                <div style={{ fontSize: '12px', color: 'var(--color-text-muted)' }}>@{acc.username}</div>
              </td>
              <td style={styles.td}>{acc.email}</td>
              <td style={styles.td}>{acc.role}</td>
              <td style={styles.td}>{acc.department}</td>
              <td style={styles.td}>{acc.lastLogin}</td>
              <td style={styles.td}>
                <span style={styles.badge(acc.status)}>{acc.status}</span>
              </td>
              <td style={styles.td}>
                <div style={styles.actions}>
                  <button style={styles.actionBtn}>Editar</button>
                  <button style={{...styles.actionBtn, color: acc.status === 'Ativo' ? 'var(--color-danger)' : 'var(--color-success)'}}>
                    {acc.status === 'Ativo' ? 'Bloquear' : 'Desbloquear'}
                  </button>
                </div>
              </td>
            </tr>
          ))}
          {filtered.length === 0 && (
            <tr>
              <td colSpan="7" style={styles.empty}>Nenhuma conta encontrada.</td>
            </tr>
          )}
        </tbody>
      </table>
      </div>
    </div>
  );
}
