import React from 'react';

export default function ConfirmModal({ isOpen, title, message, onConfirm, onCancel, confirmText = 'Confirmar', cancelText = 'Cancelar', isDestructive = false }) {
  if (!isOpen) return null;

  return (
    <div style={styles.overlay}>
      <div style={styles.modal}>
        <div style={styles.header}>
          <h3 style={styles.title}>{title || 'Atenção'}</h3>
          <button onClick={onCancel} style={styles.closeBtn}>×</button>
        </div>
        <div style={styles.body}>
          <p style={styles.message}>{message}</p>
        </div>
        <div style={styles.footer}>
          <button onClick={onCancel} style={styles.btnCancel}>{cancelText}</button>
          <button onClick={onConfirm} style={isDestructive ? styles.btnDestructive : styles.btnConfirm}>
            {confirmText}
          </button>
        </div>
      </div>
    </div>
  );
}

const styles = {
  overlay: {
    position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    zIndex: 9999, animation: 'fadeIn 0.2s ease'
  },
  modal: {
    backgroundColor: 'var(--color-bg-card, #ffffff)',
    borderRadius: '12px',
    width: '90%', maxWidth: '400px',
    boxShadow: '0 10px 25px rgba(0,0,0,0.2)',
    overflow: 'hidden', animation: 'slideUp 0.3s ease'
  },
  header: {
    padding: '16px 20px',
    borderBottom: '1px solid var(--color-border, #e2e8f0)',
    display: 'flex', justifyContent: 'space-between', alignItems: 'center'
  },
  title: { margin: 0, fontSize: '18px', fontWeight: '600', color: 'var(--color-text-base, #2d3748)' },
  closeBtn: { background: 'none', border: 'none', fontSize: '24px', cursor: 'pointer', color: '#a0aec0' },
  body: { padding: '24px 20px' },
  message: { margin: 0, fontSize: '15px', color: 'var(--color-text-muted, #4a5568)', lineHeight: '1.5' },
  footer: {
    padding: '16px 20px',
    backgroundColor: 'var(--color-bg-base, #f7fafc)',
    borderTop: '1px solid var(--color-border, #e2e8f0)',
    display: 'flex', justifyContent: 'flex-end', gap: '12px'
  },
  btnCancel: {
    padding: '10px 16px', borderRadius: '6px', border: '1px solid var(--color-border, #cbd5e0)',
    backgroundColor: 'transparent', color: 'var(--color-text-base, #4a5568)',
    fontWeight: '600', cursor: 'pointer', fontSize: '14px', transition: 'all 0.2s'
  },
  btnConfirm: {
    padding: '10px 16px', borderRadius: '6px', border: 'none',
    backgroundColor: 'var(--color-primary, #3182ce)', color: 'var(--color-accent, #ffffff)',
    fontWeight: '600', cursor: 'pointer', fontSize: '14px', transition: 'all 0.2s'
  },
  btnDestructive: {
    padding: '10px 16px', borderRadius: '6px', border: 'none',
    backgroundColor: '#e53e3e', color: '#ffffff',
    fontWeight: '600', cursor: 'pointer', fontSize: '14px', transition: 'all 0.2s'
  }
};
