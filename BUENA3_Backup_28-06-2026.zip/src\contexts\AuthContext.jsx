import React, { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    try {
      const savedUser = localStorage.getItem('sernic_logged_user');
      return savedUser ? JSON.parse(savedUser) : null;
    } catch {
      return null;
    }
  });

  const login = (userData) => {
    setUser(userData);
    localStorage.setItem('sernic_logged_user', JSON.stringify(userData));
    localStorage.setItem('sernic_last_activity', Date.now().toString());
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('sernic_logged_user');
    localStorage.removeItem('sernic_last_activity');
  };

  const updateSessionActivity = () => {
    if (user) {
      localStorage.setItem('sernic_last_activity', Date.now().toString());
    }
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, updateSessionActivity }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
