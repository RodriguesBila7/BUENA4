import { useState, useEffect } from 'react';

const STORAGE_KEY = 'sernic_disciplinary_data';

let globalDisciplinaryData = null;
const disciplinaryDataListeners = new Set();

const loadGlobalDisciplinaryData = () => {
  if (globalDisciplinaryData) return globalDisciplinaryData;
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      globalDisciplinaryData = JSON.parse(saved);
      return globalDisciplinaryData;
    }
  } catch {
    // fallthrough
  }
  globalDisciplinaryData = [];
  return globalDisciplinaryData;
};

const setGlobalDisciplinaryData = (updater) => {
  const nextData = typeof updater === 'function' ? updater(globalDisciplinaryData) : updater;
  globalDisciplinaryData = nextData;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(nextData));
  disciplinaryDataListeners.forEach(listener => listener(nextData));
};

export default function useDisciplinaryData() {
  const [processes, setLocalProcesses] = useState(loadGlobalDisciplinaryData);

  useEffect(() => {
    const listener = (newData) => setLocalProcesses(newData);
    disciplinaryDataListeners.add(listener);
    return () => {
      disciplinaryDataListeners.delete(listener);
    };
  }, []);

  const generateId = () => Math.random().toString(36).substr(2, 9);

  const addProcess = (processData) => {
    const newProcess = {
      ...processData,
      id: generateId(),
      createdAt: new Date().toISOString(),
      isActive: true // Soft delete flag
    };
    
    setGlobalDisciplinaryData([...globalDisciplinaryData, newProcess]);
    return { success: true, process: newProcess };
  };

  const updateProcess = (id, processData) => {
    setGlobalDisciplinaryData(globalDisciplinaryData.map(p => 
      p.id === id ? { ...p, ...processData, updatedAt: new Date().toISOString() } : p
    ));
    return { success: true };
  };

  const deleteProcess = (id) => {
    setGlobalDisciplinaryData(globalDisciplinaryData.map(p => 
      p.id === id ? { ...p, isActive: false, deletedAt: new Date().toISOString() } : p
    ));
    return { success: true };
  };

  const getProcessesByEmployee = (employeeId) => {
    return globalDisciplinaryData.filter(p => p.employeeId === employeeId && p.isActive);
  };

  const getAllActiveProcesses = () => {
    return globalDisciplinaryData.filter(p => p.isActive);
  };

  return {
    processes,
    addProcess,
    updateProcess,
    deleteProcess,
    getProcessesByEmployee,
    getAllActiveProcesses
  };
}
