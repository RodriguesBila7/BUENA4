import { useState, useEffect } from 'react';
import { mozambiqueStructure } from '../utils/mozambiqueDistricts';

const STORAGE_KEY = 'sernic_org_data';

const DEFAULT_DATA = {
  directorates: [], // { id, name, isActive }
  departments: [],  // { id, directorateId, name, isActive }
  divisions: [],    // { id, departmentId, name, isActive }
  sections: [],     // { id, divisionId, departmentId, name, isActive }
  careers: [],      // { id, name, isActive }
  categories: [],   // { id, careerId, name, isActive }
};

let globalOrgData = null;
const orgDataListeners = new Set();

const loadGlobalOrgData = () => {
  if (globalOrgData) return globalOrgData;
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      globalOrgData = {
        directorates: (parsed.directorates || []).map(i => ({ ...i, isActive: i.isActive !== false })),
        departments: (parsed.departments || []).map(i => ({ ...i, isActive: i.isActive !== false })),
        divisions: (parsed.divisions || []).map(i => ({ ...i, isActive: i.isActive !== false })),
        sections: (parsed.sections || []).map(i => ({ ...i, isActive: i.isActive !== false })),
        careers: (parsed.careers || []).map(i => ({ ...i, isActive: i.isActive !== false })),
        categories: (parsed.categories || []).map(i => ({ ...i, isActive: i.isActive !== false })),
      };
      return globalOrgData;
    }
  } catch {
    // fallthrough
  }
  globalOrgData = DEFAULT_DATA;
  return globalOrgData;
};

const setGlobalOrgData = (updater) => {
  const nextData = typeof updater === 'function' ? updater(globalOrgData) : updater;
  globalOrgData = nextData;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(nextData));
  orgDataListeners.forEach(listener => listener(nextData));
};

export default function useOrgData() {
  const [data, setLocalData] = useState(loadGlobalOrgData);

  useEffect(() => {
    const listener = (newData) => setLocalData(newData);
    orgDataListeners.add(listener);
    return () => {
      orgDataListeners.delete(listener);
    };
  }, []);

  const setData = setGlobalOrgData;

  const generateId = () => Math.random().toString(36).substr(2, 9);

  // --- Helpers ---
  const checkDuplicate = (list, name, parentKey, parentId) => {
    return list.some(
      (item) => item.name.toLowerCase() === name.toLowerCase() && (!parentKey || item[parentKey] === parentId)
    );
  };

  const toggleStatus = (listName, id) => {
    setData(prev => ({
      ...prev,
      [listName]: prev[listName].map(item => item.id === id ? { ...item, isActive: !item.isActive } : item)
    }));
  };

  const reorderItem = (listName, id, direction) => {
    setData(prev => {
      const list = [...(prev[listName] || [])];
      const index = list.findIndex(item => item.id === id);
      if (index === -1) return prev;
      
      if (direction === 'up' && index > 0) {
        const temp = list[index];
        list[index] = list[index - 1];
        list[index - 1] = temp;
      } else if (direction === 'down' && index < list.length - 1) {
        const temp = list[index];
        list[index] = list[index + 1];
        list[index + 1] = temp;
      } else {
        return prev;
      }
      
      return { ...prev, [listName]: list };
    });
  };

  const moveItem = (listName, sourceId, targetId) => {
    setData(prev => {
      const list = [...(prev[listName] || [])];
      const srcIndex = list.findIndex(item => item.id === sourceId);
      const tgtIndex = list.findIndex(item => item.id === targetId);
      if (srcIndex === -1 || tgtIndex === -1 || srcIndex === tgtIndex) return prev;
      
      const [movedItem] = list.splice(srcIndex, 1);
      list.splice(tgtIndex, 0, movedItem);
      
      return { ...prev, [listName]: list };
    });
  };

  // --- Direcções ---
  const addDirectorate = (name) => {
    if (checkDuplicate(data.directorates, name)) return false;
    setData((prev) => ({ ...prev, directorates: [...prev.directorates, { id: generateId(), name, isActive: true }] }));
    return true;
  };

  const updateDirectorate = (id, name) => {
    if (checkDuplicate(data.directorates.filter(d => d.id !== id), name)) return false;
    setData((prev) => ({
      ...prev,
      directorates: prev.directorates.map((d) => (d.id === id ? { ...d, name } : d)),
    }));
    return true;
  };

  const deleteDirectorate = (id) => {
    const hasChildren = data.departments.some((d) => d.directorateId === id);
    if (hasChildren) return false;
    setData((prev) => ({
      ...prev,
      directorates: prev.directorates.filter((d) => d.id !== id),
    }));
    return true;
  };

  // --- Departamentos (e Direcções Distritais) ---
  const addDepartment = (directorateId, name) => {
    if (checkDuplicate(data.departments, name, 'directorateId', directorateId)) return false;
    setData((prev) => ({ ...prev, departments: [...prev.departments, { id: generateId(), directorateId, name, isActive: true }] }));
    return true;
  };

  const updateDepartment = (id, name) => {
    const target = data.departments.find(d => d.id === id);
    if (!target) return false;
    if (checkDuplicate(data.departments.filter(d => d.id !== id), name, 'directorateId', target.directorateId)) return false;
    setData((prev) => ({
      ...prev,
      departments: prev.departments.map((d) => (d.id === id ? { ...d, name } : d)),
    }));
    return true;
  };

  const deleteDepartment = (id) => {
    const hasDivisions = data.divisions.some((d) => d.departmentId === id);
    const hasSections = data.sections.some((s) => s.departmentId === id);
    if (hasDivisions || hasSections) return false;
    setData((prev) => ({
      ...prev,
      departments: prev.departments.filter((d) => d.id !== id),
    }));
    return true;
  };

  // --- Repartições ---
  const addDivision = (departmentId, name) => {
    if (checkDuplicate(data.divisions, name, 'departmentId', departmentId)) return false;
    setData((prev) => ({ ...prev, divisions: [...prev.divisions, { id: generateId(), departmentId, name, isActive: true }] }));
    return true;
  };

  const updateDivision = (id, name) => {
    const target = data.divisions.find(d => d.id === id);
    if (!target) return false;
    if (checkDuplicate(data.divisions.filter(d => d.id !== id), name, 'departmentId', target.departmentId)) return false;
    setData((prev) => ({
      ...prev,
      divisions: prev.divisions.map((d) => (d.id === id ? { ...d, name } : d)),
    }));
    return true;
  };

  const deleteDivision = (id) => {
    const hasChildren = data.sections.some((s) => s.divisionId === id);
    if (hasChildren) return false;
    setData((prev) => ({
      ...prev,
      divisions: prev.divisions.filter((d) => d.id !== id),
    }));
    return true;
  };

  // --- Secções ---
  const addSection = (parentId, name, parentType = 'divisionId') => {
    if (checkDuplicate(data.sections, name, parentType, parentId)) return false;
    setData((prev) => ({ 
      ...prev, 
      sections: [...prev.sections, { id: generateId(), [parentType]: parentId, name, isActive: true }] 
    }));
    return true;
  };

  const updateSection = (id, name, parentId, parentType = 'divisionId') => {
    const target = data.sections.find(d => d.id === id);
    if (!target) return false;
    if (checkDuplicate(data.sections.filter(d => d.id !== id), name, parentType, parentId)) return false;
    
    setData((prev) => ({
      ...prev,
      sections: prev.sections.map((d) => {
        if (d.id === id) {
          const newSec = { ...d, name, [parentType]: parentId };
          // Remove the old linkage if changing parent type
          if (parentType === 'divisionId') delete newSec.departmentId;
          if (parentType === 'departmentId') delete newSec.divisionId;
          return newSec;
        }
        return d;
      }),
    }));
    return true;
  };

  const deleteSection = (id) => {
    setData((prev) => ({
      ...prev,
      sections: prev.sections.filter((d) => d.id !== id),
    }));
    return true;
  };

  // --- Carreiras ---
  const addCareer = (name) => {
    if (checkDuplicate(data.careers || [], name)) return false;
    setData((prev) => ({ ...prev, careers: [...(prev.careers || []), { id: generateId(), name, isActive: true }] }));
    return true;
  };

  const updateCareer = (id, name) => {
    if (checkDuplicate((data.careers || []).filter(c => c.id !== id), name)) return false;
    setData((prev) => ({
      ...prev,
      careers: (prev.careers || []).map((c) => (c.id === id ? { ...c, name } : c)),
    }));
    return true;
  };

  const deleteCareer = (id) => {
    const hasCategories = (data.categories || []).some((c) => c.careerId === id);
    if (hasCategories) return false;
    setData((prev) => ({
      ...prev,
      careers: (prev.careers || []).filter((c) => c.id !== id),
    }));
    return true;
  };

  // --- Categorias Funcionais ---
  const addCategory = (careerId, name) => {
    if (checkDuplicate(data.categories, name, 'careerId', careerId)) return false;
    setData((prev) => ({ ...prev, categories: [...prev.categories, { id: generateId(), careerId, name, isActive: true }] }));
    return true;
  };

  const updateCategory = (id, careerId, name) => {
    const target = data.categories.find(c => c.id === id);
    if (!target) return false;
    if (checkDuplicate(data.categories.filter(c => c.id !== id), name, 'careerId', careerId)) return false;
    setData((prev) => ({
      ...prev,
      categories: prev.categories.map((c) => (c.id === id ? { ...c, careerId, name } : c)),
    }));
    return true;
  };

  const deleteCategory = (id) => {
    setData((prev) => ({
      ...prev,
      categories: prev.categories.filter((c) => c.id !== id),
    }));
    return true;
  };

  // --- Bootstrap National Structure ---
  const bootstrapNationalStructure = () => {
    const newDirs = [];
    const newDeps = [];

    mozambiqueStructure.forEach(prov => {
      const dirId = generateId() + Math.random().toString(36).substr(2, 5);
      newDirs.push({ id: dirId, name: prov.province, isActive: true });

      prov.districts.forEach(dist => {
        const depId = generateId() + Math.random().toString(36).substr(2, 5);
        newDeps.push({ id: depId, directorateId: dirId, name: `Direcção Distrital de ${dist}`, isActive: true });
      });
    });

    setData(prev => {
      const existingDirNames = new Set(prev.directorates.map(d => d.name));
      const existingDepNames = new Set(prev.departments.map(d => d.name));

      const dirsToAdd = newDirs.filter(d => !existingDirNames.has(d.name));
      const depsToAdd = newDeps.filter(d => !existingDepNames.has(d.name));

      return {
        ...prev,
        directorates: [...prev.directorates, ...dirsToAdd],
        departments: [...prev.departments, ...depsToAdd]
      };
    });
  };

  return {
    data,
    toggleStatus,
    addDirectorate, updateDirectorate, deleteDirectorate,
    addDepartment, updateDepartment, deleteDepartment,
    addDivision, updateDivision, deleteDivision,
    addSection, updateSection, deleteSection,
    addCareer, updateCareer, deleteCareer,
    addCategory, updateCategory, deleteCategory,
    bootstrapNationalStructure,
    reorderItem,
    moveItem
  };
}
