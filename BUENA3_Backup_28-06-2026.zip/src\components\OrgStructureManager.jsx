import React, { useState } from 'react';
import useOrgData from '../hooks/useOrgData';
import ConfirmModal from './ConfirmModal';

export default function OrgStructureManager({ t }) {
  const {
    data, toggleStatus,
    addDirectorate, updateDirectorate, deleteDirectorate,
    addDepartment, updateDepartment, deleteDepartment,
    addDivision, updateDivision, deleteDivision,
    addSection, updateSection, deleteSection,
    addCareer, updateCareer, deleteCareer,
    addCategory, updateCategory, deleteCategory,
    bootstrapNationalStructure,
    reorderItem, moveItem
  } = useOrgData();

  const [activeTab, setActiveTab] = useState('dir');
  const [editingId, setEditingId] = useState(null);

  // Drag and Drop state
  const [draggedId, setDraggedId] = useState(null);
  const [dragOverId, setDragOverId] = useState(null);

  const handleDragStart = (e, id) => {
    setDraggedId(id);
    e.dataTransfer.effectAllowed = 'move';
  };
  const handleDragOver = (e) => { 
    e.preventDefault(); 
    
    // Auto-scroll para facilitar arrasto
    const SCROLL_MARGIN = 80;
    const SCROLL_SPEED = 15;
    
    // Tentar rolar a janela/documento principal
    if (e.clientY < SCROLL_MARGIN) {
      window.scrollBy(0, -SCROLL_SPEED);
      document.body.scrollBy(0, -SCROLL_SPEED);
    } else if (window.innerHeight - e.clientY < SCROLL_MARGIN) {
      window.scrollBy(0, SCROLL_SPEED);
      document.body.scrollBy(0, SCROLL_SPEED);
    }

    // Tentar rolar containers internos (caso a main area tenha overflow: auto)
    const scrollContainers = document.querySelectorAll('main, div');
    for (let container of scrollContainers) {
      const style = window.getComputedStyle(container);
      if (style.overflowY === 'auto' || style.overflowY === 'scroll') {
        const rect = container.getBoundingClientRect();
        if (e.clientX >= rect.left && e.clientX <= rect.right && e.clientY >= rect.top && e.clientY <= rect.bottom) {
          if (e.clientY - rect.top < SCROLL_MARGIN) {
            container.scrollBy(0, -SCROLL_SPEED);
            break; // Já encontrou o container sob o cursor
          } else if (rect.bottom - e.clientY < SCROLL_MARGIN) {
            container.scrollBy(0, SCROLL_SPEED);
            break;
          }
        }
      }
    }
  };
  const handleDragEnter = (id) => { setDragOverId(id); };
  const handleDragLeave = () => { setDragOverId(null); };
  const handleDrop = (e, targetId) => {
    e.preventDefault();
    setDragOverId(null);
    if (draggedId && draggedId !== targetId) {
      moveItem(getListName(activeTab), draggedId, targetId);
    }
    setDraggedId(null);
  };

  const getTrProps = (id) => ({
    style: {
      ...styles.tr,
      opacity: draggedId === id ? 0.5 : 1,
      borderTop: dragOverId === id ? '2px dashed var(--color-primary)' : 'none',
      backgroundColor: dragOverId === id ? 'rgba(27, 54, 93, 0.05)' : 'transparent',
    },
    draggable: true,
    onDragStart: (e) => handleDragStart(e, id),
    onDragOver: handleDragOver,
    onDragEnter: () => handleDragEnter(id),
    onDragLeave: handleDragLeave,
    onDrop: (e) => handleDrop(e, id)
  });
  
  // Form states
  const [name, setName] = useState('');
  const [parentDirId, setParentDirId] = useState('');
  const [parentDepId, setParentDepId] = useState('');
  const [parentRepId, setParentRepId] = useState('');
  const [parentCarId, setParentCarId] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const [confirmModal, setConfirmModal] = useState({ isOpen: false, title: '', message: '', action: null, isDestructive: false });

  const resetForm = () => {
    setName('');
    setParentDirId('');
    setParentDepId('');
    setParentRepId('');
    setParentCarId('');
    setEditingId(null);
    setErrorMsg('');
  };

  const handleTabChange = (tab) => {
    setActiveTab(tab);
    resetForm();
  };

  const showError = (msgKey) => {
    setErrorMsg(t(msgKey));
    setTimeout(() => setErrorMsg(''), 4000);
  };

  const handleSave = (e) => {
    e.preventDefault();
    if (!name.trim()) return;

    let success = false;

    if (activeTab === 'dir') {
      if (editingId) success = updateDirectorate(editingId, name);
      else success = addDirectorate(name);
    } else if (activeTab === 'dep') {
      if (!parentDirId) return showError('org_select_dir');
      if (editingId) success = updateDepartment(editingId, name);
      else success = addDepartment(parentDirId, name);
    } else if (activeTab === 'rep') {
      if (!parentDepId) return showError('org_select_dep');
      if (editingId) success = updateDivision(editingId, name);
      else success = addDivision(parentDepId, name);
    } else if (activeTab === 'sec') {
      if (!parentDepId) return showError('org_select_dep');
      const pId = parentRepId || parentDepId;
      const pType = parentRepId ? 'divisionId' : 'departmentId';
      if (editingId) success = updateSection(editingId, name, pId, pType);
      else success = addSection(pId, name, pType);
    } else if (activeTab === 'car') {
      if (editingId) success = updateCareer(editingId, name);
      else success = addCareer(name);
    } else if (activeTab === 'cat') {
      if (!parentCarId) return showError('Selecione a Carreira');
      if (editingId) success = updateCategory(editingId, parentCarId, name);
      else success = addCategory(parentCarId, name);
    }

    if (!success) {
      showError('msg_org_duplicate');
    } else {
      resetForm();
    }
  };

  const handleEdit = (item) => {
    setEditingId(item.id);
    setName(item.name);
    
    if (activeTab === 'dep') {
      setParentDirId(item.directorateId);
    } else if (activeTab === 'rep') {
      setParentDepId(item.departmentId);
      const dep = data.departments.find(d => d.id === item.departmentId);
      if (dep) setParentDirId(dep.directorateId);
    } else if (activeTab === 'sec') {
      if (item.divisionId) {
        setParentRepId(item.divisionId);
        const rep = data.divisions.find(r => r.id === item.divisionId);
        if (rep) {
          setParentDepId(rep.departmentId);
          const dep = data.departments.find(d => d.id === rep.departmentId);
          if (dep) setParentDirId(dep.directorateId);
        }
      } else if (item.departmentId) {
        setParentRepId('');
        setParentDepId(item.departmentId);
        const dep = data.departments.find(d => d.id === item.departmentId);
        if (dep) setParentDirId(dep.directorateId);
      }
    } else if (activeTab === 'cat') {
      setParentCarId(item.careerId);
    }
    setErrorMsg('');
  };

  const requestDelete = (id) => {
    setConfirmModal({
      isOpen: true,
      title: 'Confirmar Eliminação',
      message: t('org_confirm_delete') || 'Tem a certeza que deseja apagar?',
      isDestructive: true,
      action: () => executeDelete(id)
    });
  };

  const executeDelete = (id) => {
    setConfirmModal(prev => ({ ...prev, isOpen: false }));
    let success = false;
    if (activeTab === 'dir') success = deleteDirectorate(id);
    else if (activeTab === 'dep') success = deleteDepartment(id);
    else if (activeTab === 'rep') success = deleteDivision(id);
    else if (activeTab === 'sec') success = deleteSection(id);
    else if (activeTab === 'car') success = deleteCareer(id);
    else if (activeTab === 'cat') success = deleteCategory(id);

    if (!success) {
      showError('msg_org_delete_blocked');
    }
  };

  const getListName = (tab) => {
    if (tab === 'dir') return 'directorates';
    if (tab === 'dep') return 'departments';
    if (tab === 'rep') return 'divisions';
    if (tab === 'sec') return 'sections';
    if (tab === 'car') return 'careers';
    if (tab === 'cat') return 'categories';
  };

  const handleToggleStatus = (id) => {
    toggleStatus(getListName(activeTab), id);
  };

  const handleReorder = (id, direction) => {
    reorderItem(getListName(activeTab), id, direction);
  };

  // Filtragem dinâmica
  const availableDepartments = data.departments.filter(d => d.directorateId === parentDirId);
  const availableDivisions = data.divisions.filter(d => d.departmentId === parentDepId);

  // List filters
  const displayDepartments = parentDirId ? data.departments.filter(d => d.directorateId === parentDirId) : data.departments;
  const displayDivisions = parentDepId ? data.divisions.filter(d => d.departmentId === parentDepId) : data.divisions;
  const displaySections = parentRepId 
    ? data.sections.filter(s => s.divisionId === parentRepId) 
    : (parentDepId ? data.sections.filter(s => s.departmentId === parentDepId) : data.sections);
  const displayCategories = parentCarId ? data.categories.filter(c => c.careerId === parentCarId) : data.categories;

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <div>
          <h2 style={styles.title}>{t('org_title')}</h2>
          <p style={styles.desc}>{t('org_desc')}</p>
        </div>
        <button 
          onClick={() => {
            setConfirmModal({
              isOpen: true,
              title: 'Carregar Estrutura Nacional',
              message: 'Pretende carregar a estrutura nacional base (11 Províncias e Distritos)? Apenas registos não existentes serão adicionados.',
              isDestructive: false,
              action: () => {
                setConfirmModal(prev => ({ ...prev, isOpen: false }));
                bootstrapNationalStructure();
              }
            });
          }}
          style={styles.bootstrapBtn}
        >
          Carregar Estrutura Nacional
        </button>
      </div>

      {/* Tabs */}
      <div style={styles.tabsContainer}>
        <button onClick={() => handleTabChange('dir')} style={activeTab === 'dir' ? styles.activeTab : styles.tab}>{t('org_tab_dir')}</button>
        <button onClick={() => handleTabChange('dep')} style={activeTab === 'dep' ? styles.activeTab : styles.tab}>{t('org_tab_dep')}</button>
        <button onClick={() => handleTabChange('rep')} style={activeTab === 'rep' ? styles.activeTab : styles.tab}>{t('org_tab_rep')}</button>
        <button onClick={() => handleTabChange('sec')} style={activeTab === 'sec' ? styles.activeTab : styles.tab}>{t('org_tab_sec')}</button>
        <button onClick={() => handleTabChange('car')} style={activeTab === 'car' ? styles.activeTab : styles.tab}>{t('org_tab_car')}</button>
        <button onClick={() => handleTabChange('cat')} style={activeTab === 'cat' ? styles.activeTab : styles.tab}>{t('org_tab_cat')}</button>
      </div>

      <div style={styles.contentArea}>
        {/* Formulário */}
        <div style={styles.formCard}>
          <h3 style={styles.cardTitle}>{editingId ? t('org_edit_title') : t(`org_create_${activeTab}`)}</h3>
          
          <form onSubmit={handleSave} style={styles.form}>
            {['dep', 'rep', 'sec'].includes(activeTab) && (
              <div style={styles.formGroup}>
                <label style={styles.label}>{t('org_tab_dir')}</label>
                <select 
                  value={parentDirId} 
                  onChange={(e) => {
                    setParentDirId(e.target.value);
                    setParentDepId('');
                    setParentRepId('');
                  }}
                  style={styles.input}
                  required
                >
                  <option value="">-- {t('org_select_dir')} --</option>
                  {data.directorates.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
                </select>
              </div>
            )}

            {['rep', 'sec'].includes(activeTab) && (
              <div style={styles.formGroup}>
                <label style={styles.label}>{t('org_tab_dep')}</label>
                <select 
                  value={parentDepId} 
                  onChange={(e) => {
                    setParentDepId(e.target.value);
                    setParentRepId('');
                  }}
                  style={styles.input}
                  required
                  disabled={!parentDirId}
                >
                  <option value="">-- {t('org_select_dep')} --</option>
                  {availableDepartments.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
                </select>
              </div>
            )}

            {activeTab === 'sec' && (
              <div style={styles.formGroup}>
                <label style={styles.label}>{t('org_tab_rep')} (Opcional para Dir. Distritais)</label>
                <select 
                  value={parentRepId} 
                  onChange={(e) => setParentRepId(e.target.value)}
                  style={styles.input}
                  disabled={!parentDepId}
                >
                  <option value="">-- Nenhuma / Ligação Direta ao Departamento --</option>
                  {availableDivisions.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
                </select>
              </div>
            )}

            {activeTab === 'cat' && (
              <div style={styles.formGroup}>
                <label style={styles.label}>{t('org_tab_car')}</label>
                <select 
                  value={parentCarId} 
                  onChange={(e) => setParentCarId(e.target.value)}
                  style={styles.input}
                  required
                >
                  <option value="">-- Selecione a Carreira --</option>
                  {(data.careers || []).filter(c => c.isActive).map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
                </select>
              </div>
            )}

            <div style={styles.formGroup}>
              <label style={styles.label}>{t('org_name')}</label>
              <input 
                type="text" 
                value={name} 
                onChange={(e) => setName(e.target.value)} 
                style={styles.input} 
                required 
              />
            </div>

            {errorMsg && <div style={styles.errorAlert}>{errorMsg}</div>}

            <div style={styles.buttonGroup}>
              <button type="submit" style={styles.btnPrimary}>
                {editingId ? t('org_save') : t('org_add')}
              </button>
              {editingId && (
                <button type="button" onClick={resetForm} style={styles.btnSecondary}>
                  {t('org_cancel')}
                </button>
              )}
            </div>
          </form>
        </div>

        {/* Lista de Registos */}
        <div style={styles.listCard}>
          <h3 style={styles.cardTitle}>Registos Guardados</h3>
          <div style={styles.tableContainer}>
            <table style={styles.table}>
              <thead>
                <tr>
                  <th style={styles.th}>{t('org_name')}</th>
                  {['dep', 'rep', 'sec'].includes(activeTab) && <th style={styles.th}>{t('org_tab_dir')}</th>}
                  {['rep', 'sec'].includes(activeTab) && <th style={styles.th}>{t('org_tab_dep')}</th>}
                  {activeTab === 'sec' && <th style={styles.th}>{t('org_tab_rep')}</th>}
                  {activeTab === 'cat' && <th style={styles.th}>{t('org_tab_car')}</th>}
                  <th style={styles.th}>{t('org_status')}</th>
                  <th style={styles.th}>Ações</th>
                </tr>
              </thead>
              <tbody>
                {activeTab === 'dir' && data.directorates.map(item => (
                  <tr key={item.id} {...getTrProps(item.id)}>
                    <td style={styles.td}>{item.name}</td>
                    <td style={styles.td}>
                      <span style={item.isActive ? styles.badgeActive : styles.badgeInactive}>
                        {item.isActive ? t('org_active') : t('org_inactive')}
                      </span>
                    </td>
                    <td style={styles.tdActions}>
                      <span style={{...styles.btnIcon, cursor: 'grab', fontSize: '16px', display: 'inline-block'}} title="Arraste para reordenar">☰</span>
                      <span style={styles.divider}></span>
                      <button onClick={() => handleToggleStatus(item.id)} style={styles.btnIcon} title="Toggle Status">⏻</button>
                      <button onClick={() => handleEdit(item)} style={styles.btnIcon}>✎</button>
                      <button onClick={() => requestDelete(item.id)} style={{...styles.btnIcon, color: '#e53e3e'}}>🗑</button>
                    </td>
                  </tr>
                ))}
                
                {activeTab === 'dep' && displayDepartments.map(item => {
                  const pDir = data.directorates.find(d => d.id === item.directorateId);
                  return (
                    <tr key={item.id} {...getTrProps(item.id)}>
                      <td style={styles.td}>{item.name}</td>
                      <td style={styles.td}>{pDir?.name || '-'}</td>
                      <td style={styles.td}>
                        <span style={item.isActive ? styles.badgeActive : styles.badgeInactive}>{item.isActive ? t('org_active') : t('org_inactive')}</span>
                      </td>
                      <td style={styles.tdActions}>
                        <span style={{...styles.btnIcon, cursor: 'grab', fontSize: '16px', display: 'inline-block'}} title="Arraste para reordenar">☰</span>
                        <span style={styles.divider}></span>
                        <button onClick={() => handleToggleStatus(item.id)} style={styles.btnIcon}>⏻</button>
                        <button onClick={() => handleEdit(item)} style={styles.btnIcon}>✎</button>
                        <button onClick={() => requestDelete(item.id)} style={{...styles.btnIcon, color: '#e53e3e'}}>🗑</button>
                      </td>
                    </tr>
                  )
                })}

                {activeTab === 'rep' && displayDivisions.map(item => {
                  const pDep = data.departments.find(d => d.id === item.departmentId);
                  const pDir = data.directorates.find(d => d.id === pDep?.directorateId);
                  return (
                    <tr key={item.id} {...getTrProps(item.id)}>
                      <td style={styles.td}>{item.name}</td>
                      <td style={styles.td}>{pDir?.name || '-'}</td>
                      <td style={styles.td}>{pDep?.name || '-'}</td>
                      <td style={styles.td}>
                        <span style={item.isActive ? styles.badgeActive : styles.badgeInactive}>{item.isActive ? t('org_active') : t('org_inactive')}</span>
                      </td>
                      <td style={styles.tdActions}>
                        <span style={{...styles.btnIcon, cursor: 'grab', fontSize: '16px', display: 'inline-block'}} title="Arraste para reordenar">☰</span>
                        <span style={styles.divider}></span>
                        <button onClick={() => handleToggleStatus(item.id)} style={styles.btnIcon}>⏻</button>
                        <button onClick={() => handleEdit(item)} style={styles.btnIcon}>✎</button>
                        <button onClick={() => requestDelete(item.id)} style={{...styles.btnIcon, color: '#e53e3e'}}>🗑</button>
                      </td>
                    </tr>
                  )
                })}

                {activeTab === 'sec' && displaySections.map(item => {
                  // Pode estar associado a uma Repartição ou a um Departamento direto
                  let pRep = null, pDep = null, pDir = null;
                  
                  if (item.divisionId) {
                    pRep = data.divisions.find(d => d.id === item.divisionId);
                    pDep = data.departments.find(d => d.id === pRep?.departmentId);
                    pDir = data.directorates.find(d => d.id === pDep?.directorateId);
                  } else if (item.departmentId) {
                    pDep = data.departments.find(d => d.id === item.departmentId);
                    pDir = data.directorates.find(d => d.id === pDep?.directorateId);
                  }

                  return (
                    <tr key={item.id} {...getTrProps(item.id)}>
                      <td style={styles.td}>{item.name}</td>
                      <td style={styles.td}>{pDir?.name || '-'}</td>
                      <td style={styles.td}>{pDep?.name || '-'}</td>
                      <td style={styles.td}>{pRep ? pRep.name : <span style={{color: '#a0aec0', fontStyle: 'italic'}}>Dir. Direta</span>}</td>
                      <td style={styles.td}>
                        <span style={item.isActive ? styles.badgeActive : styles.badgeInactive}>{item.isActive ? t('org_active') : t('org_inactive')}</span>
                      </td>
                      <td style={styles.tdActions}>
                        <span style={{...styles.btnIcon, cursor: 'grab', fontSize: '16px', display: 'inline-block'}} title="Arraste para reordenar">☰</span>
                        <span style={styles.divider}></span>
                        <button onClick={() => handleToggleStatus(item.id)} style={styles.btnIcon}>⏻</button>
                        <button onClick={() => handleEdit(item)} style={styles.btnIcon}>✎</button>
                        <button onClick={() => requestDelete(item.id)} style={{...styles.btnIcon, color: '#e53e3e'}}>🗑</button>
                      </td>
                    </tr>
                  )
                })}

                {activeTab === 'car' && (data.careers || []).map(item => (
                  <tr key={item.id} {...getTrProps(item.id)}>
                    <td style={styles.td}>{item.name}</td>
                    <td style={styles.td}>
                      <span style={item.isActive ? styles.badgeActive : styles.badgeInactive}>{item.isActive ? t('org_active') : t('org_inactive')}</span>
                    </td>
                    <td style={styles.tdActions}>
                      <button onClick={() => handleReorder(item.id, 'up')} style={styles.btnIcon} title="Mover para Cima">↑</button>
                      <button onClick={() => handleReorder(item.id, 'down')} style={styles.btnIcon} title="Mover para Baixo">↓</button>
                      <span style={styles.divider}></span>
                      <button onClick={() => handleToggleStatus(item.id)} style={styles.btnIcon}>⏻</button>
                      <button onClick={() => handleEdit(item)} style={styles.btnIcon}>✎</button>
                      <button onClick={() => requestDelete(item.id)} style={{...styles.btnIcon, color: '#e53e3e'}}>🗑</button>
                    </td>
                  </tr>
                ))}

                {activeTab === 'cat' && displayCategories.map(item => {
                  const pCar = (data.careers || []).find(c => c.id === item.careerId);
                  return (
                    <tr key={item.id} {...getTrProps(item.id)}>
                      <td style={styles.td}>{item.name}</td>
                      <td style={styles.td}>{pCar?.name || '-'}</td>
                      <td style={styles.td}>
                        <span style={item.isActive ? styles.badgeActive : styles.badgeInactive}>{item.isActive ? t('org_active') : t('org_inactive')}</span>
                      </td>
                      <td style={styles.tdActions}>
                        <span style={{...styles.btnIcon, cursor: 'grab', fontSize: '16px', display: 'inline-block'}} title="Arraste para reordenar">☰</span>
                        <span style={styles.divider}></span>
                        <button onClick={() => handleToggleStatus(item.id)} style={styles.btnIcon}>⏻</button>
                        <button onClick={() => handleEdit(item)} style={styles.btnIcon}>✎</button>
                        <button onClick={() => requestDelete(item.id)} style={{...styles.btnIcon, color: '#e53e3e'}}>🗑</button>
                      </td>
                    </tr>
                  )
                })}

                {/* Empty states */}
                {activeTab === 'dir' && data.directorates.length === 0 && <tr style={styles.tr}><td colSpan="4" style={styles.empty}>{t('org_empty')}</td></tr>}
                {activeTab === 'dep' && displayDepartments.length === 0 && <tr style={styles.tr}><td colSpan="5" style={styles.empty}>{t('org_empty')}</td></tr>}
                {activeTab === 'rep' && displayDivisions.length === 0 && <tr style={styles.tr}><td colSpan="6" style={styles.empty}>{t('org_empty')}</td></tr>}
                {activeTab === 'sec' && displaySections.length === 0 && <tr style={styles.tr}><td colSpan="7" style={styles.empty}>{t('org_empty')}</td></tr>}
                {activeTab === 'car' && (!data.careers || data.careers.length === 0) && <tr style={styles.tr}><td colSpan="4" style={styles.empty}>{t('org_empty')}</td></tr>}
                {activeTab === 'cat' && displayCategories.length === 0 && <tr style={styles.tr}><td colSpan="5" style={styles.empty}>{t('org_empty')}</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      </div>
      
      <ConfirmModal
        isOpen={confirmModal.isOpen}
        title={confirmModal.title}
        message={confirmModal.message}
        isDestructive={confirmModal.isDestructive}
        onConfirm={confirmModal.action}
        onCancel={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
      />
    </div>
  );
}

const styles = {
  container: { padding: '30px', animation: 'fadeIn 0.4s ease-out' },
  header: { marginBottom: '24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' },
  title: { fontSize: '24px', fontWeight: '700', color: 'var(--color-primary)', marginBottom: '8px' },
  desc: { color: 'var(--color-text-muted)', fontSize: '15px' },
  bootstrapBtn: { backgroundColor: '#3182ce', color: '#fff', border: 'none', padding: '10px 16px', borderRadius: '6px', fontWeight: '600', cursor: 'pointer', boxShadow: '0 2px 4px rgba(49, 130, 206, 0.3)' },
  tabsContainer: { display: 'flex', gap: '4px', marginBottom: '24px', borderBottom: '1px solid var(--color-border)', flexWrap: 'wrap' },
  tab: { padding: '12px 20px', background: 'transparent', border: 'none', color: 'var(--color-text-muted)', fontSize: '14px', fontWeight: '600', cursor: 'pointer', borderBottom: '3px solid transparent', transition: 'all 0.2s' },
  activeTab: { padding: '12px 20px', background: 'transparent', border: 'none', color: 'var(--color-primary)', fontSize: '14px', fontWeight: '600', cursor: 'pointer', borderBottom: '3px solid var(--color-primary)', transition: 'all 0.2s' },
  contentArea: { display: 'grid', gridTemplateColumns: '350px 1fr', gap: '24px', alignItems: 'start' },
  formCard: { backgroundColor: 'var(--color-bg-card)', padding: '24px', borderRadius: '12px', border: '1px solid var(--color-border)', boxShadow: '0 4px 6px rgba(0,0,0,0.02)' },
  listCard: { backgroundColor: 'var(--color-bg-card)', padding: '24px', borderRadius: '12px', border: '1px solid var(--color-border)', boxShadow: '0 4px 6px rgba(0,0,0,0.02)' },
  cardTitle: { fontSize: '16px', fontWeight: '600', marginBottom: '20px', color: 'var(--color-primary)' },
  formGroup: { marginBottom: '16px' },
  label: { display: 'block', fontSize: '13px', fontWeight: '600', color: 'var(--color-text-base)', marginBottom: '8px' },
  input: { width: '100%', padding: '10px 12px', borderRadius: '6px', border: '1px solid var(--color-border)', backgroundColor: 'var(--color-bg-base)', color: 'var(--color-text-base)', fontSize: '14px' },
  buttonGroup: { display: 'flex', gap: '12px', marginTop: '24px' },
  btnPrimary: { padding: '10px 16px', backgroundColor: 'var(--color-primary)', color: 'var(--color-accent)', border: 'none', borderRadius: '6px', fontSize: '14px', fontWeight: '600', cursor: 'pointer', flex: 1 },
  btnSecondary: { padding: '10px 16px', backgroundColor: 'transparent', color: 'var(--color-text-base)', border: '1px solid var(--color-border)', borderRadius: '6px', fontSize: '14px', fontWeight: '600', cursor: 'pointer' },
  errorAlert: { marginTop: '12px', padding: '10px', backgroundColor: 'rgba(229, 62, 62, 0.1)', color: '#e53e3e', borderRadius: '6px', fontSize: '13px', fontWeight: '500' },
  tableContainer: { overflowX: 'auto' },
  table: { width: '100%', borderCollapse: 'collapse', fontSize: '14px' },
  th: { textAlign: 'left', padding: '12px', borderBottom: '2px solid var(--color-border)', color: 'var(--color-text-muted)', fontWeight: '600' },
  tr: { borderBottom: '1px solid var(--color-border)' },
  td: { padding: '12px', color: 'var(--color-text-base)' },
  tdActions: { padding: '12px', display: 'flex', gap: '8px', alignItems: 'center' },
  divider: { width: '1px', height: '16px', backgroundColor: 'var(--color-border)', margin: '0 4px' },
  btnIcon: { background: 'transparent', border: 'none', cursor: 'pointer', fontSize: '16px', color: 'var(--color-text-muted)', transition: 'color 0.2s' },
  empty: { textAlign: 'center', padding: '30px', color: 'var(--color-text-muted)', fontStyle: 'italic' },
  badgeActive: { backgroundColor: 'rgba(72, 187, 120, 0.15)', color: '#2f855a', padding: '4px 8px', borderRadius: '12px', fontSize: '12px', fontWeight: '600' },
  badgeInactive: { backgroundColor: 'rgba(160, 174, 192, 0.15)', color: '#718096', padding: '4px 8px', borderRadius: '12px', fontSize: '12px', fontWeight: '600' }
};
