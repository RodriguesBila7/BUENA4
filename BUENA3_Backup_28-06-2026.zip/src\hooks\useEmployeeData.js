import { useState, useEffect, useMemo } from 'react';
import { useAuth } from '../contexts/AuthContext';

const STORAGE_KEY = 'sernic_employees_data';

let globalEmployeesData = null;
const employeesDataListeners = new Set();

const loadGlobalEmployeesData = () => {
  if (globalEmployeesData) return globalEmployeesData;
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      globalEmployeesData = JSON.parse(saved);
      return globalEmployeesData;
    }
  } catch {
    // fallthrough
  }
  globalEmployeesData = [];
  return globalEmployeesData;
};

const setGlobalEmployeesData = (updater) => {
  const nextData = typeof updater === 'function' ? updater(globalEmployeesData) : updater;
  globalEmployeesData = nextData;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(nextData));
  employeesDataListeners.forEach(listener => listener(nextData));
};

export default function useEmployeeData() {
  const { user: currentUser } = useAuth();
  const [employeesRaw, setLocalEmployees] = useState(loadGlobalEmployeesData);

  useEffect(() => {
    const listener = (newData) => setLocalEmployees(newData);
    employeesDataListeners.add(listener);
    return () => {
      employeesDataListeners.delete(listener);
    };
  }, []);

  const setEmployees = setGlobalEmployeesData;

  const employees = useMemo(() => {
    if (!currentUser) return employeesRaw;
    if (currentUser.roleId === 'super_admin' || currentUser.roleId === 'hr_manager') return employeesRaw;

    return employeesRaw.filter(emp => {
      let keep = true;
      if (currentUser.directorateId && emp.directorateId !== currentUser.directorateId) keep = false;
      if (currentUser.departmentId && emp.departmentId !== currentUser.departmentId) keep = false;
      if (currentUser.divisionId && emp.divisionId !== currentUser.divisionId) keep = false;
      if (currentUser.sectionId && emp.sectionId !== currentUser.sectionId) keep = false;
      return keep;
    });
  }, [employeesRaw, currentUser]);

  const generateId = () => Math.random().toString(36).substr(2, 9);

  const checkDuplicateNIP = (list, nip, excludeId = null) => {
    return list.some(emp => emp.nip === nip && emp.id !== excludeId);
  };

  const addEmployee = (empData) => {
    if (checkDuplicateNIP(employeesRaw, empData.nip)) return { success: false, error: 'nip_duplicate' };
    
    const newEmp = { 
      ...empData, 
      id: generateId(), 
      createdAt: new Date().toISOString() 
    };
    
    setEmployees(prev => [...prev, newEmp]);
    return { success: true, employee: newEmp };
  };

  const updateEmployee = (id, empData) => {
    if (checkDuplicateNIP(employeesRaw, empData.nip, id)) return { success: false, error: 'nip_duplicate' };
    
    setEmployees(prev => prev.map(emp => emp.id === id ? { ...emp, ...empData, updatedAt: new Date().toISOString() } : emp));
    return { success: true };
  };

  const deleteEmployee = (id) => {
    setEmployees(prev => prev.filter(emp => emp.id !== id));
    return { success: true };
  };

  const bulkAddEmployees = (empArray) => {
    const validEmps = [];
    const errors = [];
    
    // Validate uniqueness within the batch and against existing DB
    const currentNips = new Set(employeesRaw.map(e => e.nip));
    const batchNips = new Set();

    empArray.forEach((emp, index) => {
      const rowNum = index + 2; // assuming row 1 is header
      if (!emp.nip || !emp.name) {
        errors.push(`Linha ${rowNum}: NIP e Nome são obrigatórios.`);
        return;
      }
      
      if (currentNips.has(emp.nip) || batchNips.has(emp.nip)) {
        errors.push(`Linha ${rowNum}: NIP ${emp.nip} já existe ou está duplicado no ficheiro.`);
        return;
      }
      
      batchNips.add(emp.nip);
      validEmps.push({
        ...emp,
        id: generateId(),
        createdAt: new Date().toISOString()
      });
    });

    if (validEmps.length > 0) {
      setEmployees(prev => [...prev, ...validEmps]);
    }

    return { 
      success: errors.length === 0, 
      added: validEmps.length, 
      errors 
    };
  };

  return {
    employees,
    addEmployee,
    updateEmployee,
    deleteEmployee,
    bulkAddEmployees
  };
}
