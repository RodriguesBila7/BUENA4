import React, { useMemo, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import useOrgData from '../hooks/useOrgData';
import { getKPIs, getChartData, getHierarchyTree, getAuditIssues } from '../services/orgAnalyticsService';

const COLORS = ['#1B365D', '#4A5568', '#718096', '#A0AEC0', '#E2E8F0'];

const KPICard = ({ title, data, t }) => (
  <div style={styles.kpiCard}>
    <h3 style={styles.kpiTitle}>{title}</h3>
    <div style={styles.kpiTotal}>{data.total}</div>
    <div style={styles.kpiDetails}>
      <span style={styles.kpiActive}>● {data.active} {t('org_active') || 'Activos'}</span>
      <span style={styles.kpiInactive}>● {data.inactive} {t('org_inactive') || 'Inactivos'}</span>
    </div>
  </div>
);

const TreeNode = ({ node }) => {
  const [expanded, setExpanded] = useState(false);
  const hasChildren = node.children && node.children.length > 0;

  return (
    <div style={styles.treeNode}>
      <div 
        style={{...styles.treeItem, cursor: hasChildren ? 'pointer' : 'default'}} 
        onClick={() => hasChildren && setExpanded(!expanded)}
      >
        <span style={styles.treeIcon}>{hasChildren ? (expanded ? '▼' : '▶') : '•'}</span>
        <span style={styles.treeLabel}>{node.name}</span>
        <span style={styles.treeTypeBadge}>{node.type.toUpperCase()}</span>
      </div>
      {expanded && hasChildren && (
        <div style={styles.treeChildren}>
          {node.children.map(child => <TreeNode key={child.id} node={child} />)}
        </div>
      )}
    </div>
  );
};

export default function HomeDashboard({ t }) {
  const { data } = useOrgData();

  const kpis = useMemo(() => getKPIs(data), [data]);
  const charts = useMemo(() => getChartData(data), [data]);
  const tree = useMemo(() => getHierarchyTree(data), [data]);
  const issues = useMemo(() => getAuditIssues(data), [data]);

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <h2 style={styles.title}>{t('dash_overview') || 'Visão Geral'}</h2>
      </div>

      {/* KPI Cards */}
      <div style={styles.kpiGrid}>
        <KPICard title={t('org_tab_dir') || 'Direcções'} data={kpis.directorates} t={t} />
        <KPICard title={t('org_tab_dep') || 'Departamentos'} data={kpis.departments} t={t} />
        <KPICard title={t('org_tab_rep') || 'Repartições'} data={kpis.divisions} t={t} />
        <KPICard title={t('org_tab_sec') || 'Secções'} data={kpis.sections} t={t} />
      </div>

      {/* Charts Row */}
      <div style={styles.chartsRow}>
        <div style={styles.chartCard}>
          <h3 style={styles.cardTitle}>Volume Estrutural</h3>
          <div style={styles.chartWrapper}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={charts.overallComparison}>
                <XAxis dataKey="name" stroke="#A0AEC0" fontSize={12} />
                <YAxis stroke="#A0AEC0" fontSize={12} allowDecimals={false} />
                <Tooltip cursor={{fill: 'rgba(0,0,0,0.02)'}} />
                <Bar dataKey="count" fill="var(--color-primary)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div style={styles.chartCard}>
          <h3 style={styles.cardTitle}>Distribuição (Departamentos por Direcção)</h3>
          <div style={styles.chartWrapper}>
            {charts.depsPerDir.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={charts.depsPerDir}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {charts.depsPerDir.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div style={styles.emptyChart}>Dados Insuficientes</div>
            )}
          </div>
        </div>
      </div>

      {/* Bottom Row: Tree & Audit */}
      <div style={styles.bottomRow}>
        <div style={styles.treeCard}>
          <h3 style={styles.cardTitle}>{t('dash_tree') || 'Hierarquia Completa'}</h3>
          <div style={styles.treeContainer}>
            {tree.length > 0 ? (
              tree.map(node => <TreeNode key={node.id} node={node} />)
            ) : (
              <div style={styles.empty}>Nenhuma estrutura definida.</div>
            )}
          </div>
        </div>

        <div style={styles.auditCard}>
          <h3 style={styles.cardTitle}>{t('dash_audit') || 'Auditoria Estrutural'}</h3>
          <div style={styles.auditContainer}>
            {issues.length === 0 ? (
              <div style={styles.healthyState}>
                <span style={styles.healthyIcon}>✓</span>
                <p>{t('dash_healthy') || 'Saudável'}</p>
                <small>Não foram detetadas inconsistências na hierarquia.</small>
              </div>
            ) : (
              <ul style={styles.issueList}>
                {issues.map((issue, idx) => (
                  <li key={idx} style={issue.type === 'orphan' ? styles.issueItemOrphan : styles.issueItemEmpty}>
                    <div style={styles.issueHeader}>
                      <strong>{issue.level}: {issue.name}</strong>
                      <span style={styles.issueBadge}>{issue.type.toUpperCase()}</span>
                    </div>
                    <p style={styles.issueMsg}>{issue.msg}</p>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

const styles = {
  container: {
    padding: '30px',
    animation: 'fadeIn 0.4s ease-out',
  },
  header: {
    marginBottom: '24px',
  },
  title: {
    fontSize: '24px',
    fontWeight: '700',
    color: 'var(--color-primary)',
    marginBottom: '8px',
  },
  kpiGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
    gap: '20px',
    marginBottom: '24px',
  },
  kpiCard: {
    backgroundColor: 'var(--color-bg-card)',
    padding: '20px',
    borderRadius: '12px',
    border: '1px solid var(--color-border)',
    boxShadow: '0 2px 4px rgba(0,0,0,0.02)',
  },
  kpiTitle: {
    fontSize: '13px',
    color: 'var(--color-text-muted)',
    fontWeight: '600',
    textTransform: 'uppercase',
    marginBottom: '12px',
  },
  kpiTotal: {
    fontSize: '32px',
    fontWeight: '700',
    color: 'var(--color-primary)',
    marginBottom: '12px',
  },
  kpiDetails: {
    display: 'flex',
    flexDirection: 'column',
    gap: '4px',
    fontSize: '12px',
    fontWeight: '600',
  },
  kpiActive: { color: '#38a169' },
  kpiInactive: { color: '#a0aec0' },
  chartsRow: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: '24px',
    marginBottom: '24px',
  },
  chartCard: {
    backgroundColor: 'var(--color-bg-card)',
    padding: '24px',
    borderRadius: '12px',
    border: '1px solid var(--color-border)',
    boxShadow: '0 2px 4px rgba(0,0,0,0.02)',
  },
  cardTitle: {
    fontSize: '16px',
    fontWeight: '600',
    color: 'var(--color-primary)',
    marginBottom: '20px',
  },
  chartWrapper: {
    height: '250px',
  },
  emptyChart: {
    height: '100%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: 'var(--color-text-muted)',
    fontSize: '14px',
  },
  bottomRow: {
    display: 'grid',
    gridTemplateColumns: '1fr 350px',
    gap: '24px',
  },
  treeCard: {
    backgroundColor: 'var(--color-bg-card)',
    padding: '24px',
    borderRadius: '12px',
    border: '1px solid var(--color-border)',
    minHeight: '300px',
  },
  treeContainer: {
    padding: '10px 0',
  },
  treeNode: {
    marginBottom: '4px',
  },
  treeItem: {
    display: 'flex',
    alignItems: 'center',
    padding: '8px',
    borderRadius: '6px',
    transition: 'background 0.2s',
    userSelect: 'none',
  },
  treeIcon: {
    width: '20px',
    color: 'var(--color-text-muted)',
    fontSize: '12px',
    display: 'flex',
    justifyContent: 'center',
  },
  treeLabel: {
    marginLeft: '8px',
    fontSize: '14px',
    color: 'var(--color-text-base)',
    fontWeight: '500',
  },
  treeTypeBadge: {
    marginLeft: '12px',
    fontSize: '10px',
    padding: '2px 6px',
    backgroundColor: 'rgba(0,0,0,0.05)',
    borderRadius: '10px',
    color: 'var(--color-text-muted)',
    fontWeight: '700',
  },
  treeChildren: {
    marginLeft: '24px',
    borderLeft: '1px solid var(--color-border)',
    paddingLeft: '12px',
    marginTop: '4px',
  },
  auditCard: {
    backgroundColor: 'var(--color-bg-card)',
    padding: '24px',
    borderRadius: '12px',
    border: '1px solid var(--color-border)',
  },
  auditContainer: {
    marginTop: '10px',
  },
  healthyState: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    textAlign: 'center',
    padding: '30px 10px',
    color: '#38a169',
  },
  healthyIcon: {
    fontSize: '48px',
    marginBottom: '10px',
  },
  issueList: {
    listStyle: 'none',
    padding: 0,
    margin: 0,
    display: 'flex',
    flexDirection: 'column',
    gap: '12px',
  },
  issueItemOrphan: {
    padding: '12px',
    backgroundColor: 'rgba(229, 62, 62, 0.05)',
    borderLeft: '4px solid #e53e3e',
    borderRadius: '0 6px 6px 0',
  },
  issueItemEmpty: {
    padding: '12px',
    backgroundColor: 'rgba(221, 107, 32, 0.05)',
    borderLeft: '4px solid #dd6b20',
    borderRadius: '0 6px 6px 0',
  },
  issueHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '6px',
    fontSize: '13px',
    color: 'var(--color-text-base)',
  },
  issueBadge: {
    fontSize: '10px',
    fontWeight: '700',
    padding: '2px 6px',
    borderRadius: '4px',
    backgroundColor: 'rgba(0,0,0,0.1)',
  },
  issueMsg: {
    fontSize: '12px',
    color: 'var(--color-text-muted)',
    lineHeight: '1.4',
  },
  empty: {
    color: 'var(--color-text-muted)',
    fontSize: '14px',
    fontStyle: 'italic',
  }
};
