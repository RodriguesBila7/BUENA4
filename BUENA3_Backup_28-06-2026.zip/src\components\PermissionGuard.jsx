import React from 'react';
import { useAuth } from '../contexts/AuthContext';

export default function PermissionGuard({ module, action, children, fallback = null }) {
  const { user } = useAuth();

  if (!user || !user.roleDetails || !user.roleDetails.permissions) return fallback;

  // Super Administrador tem acesso total independente da matriz caso haja uma falha, mas a matriz
  // do Super Administrador já inclui tudo por default.
  
  const modulePerms = user.roleDetails.permissions[module] || [];
  
  if (modulePerms.includes(action)) {
    return children;
  }
  
  return fallback;
}
