import React, { useState, useEffect, useCallback } from 'react';
import { fetchEmployees, getEmployeeStats } from '../../services/employeeApiService';
import AdvancedFilters from './AdvancedFilters';
import EmployeeStats from './EmployeeStats';
import ConfirmModal from '../ConfirmModal';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import useDisciplinaryData from '../../hooks/useDisciplinaryData';

export default function EmployeeViewer({ employees, orgData, onEdit, onDelete }) {
  const { data } = orgData;
  const { getProcessesByEmployee } = useDisciplinaryData();

  const [activeTab, setActiveTab] = useState('all'); // 'all' or 'org'
  const [filters, setFilters] = useState({
    searchTerm: '',
    directorateId: '', departmentId: '', divisionId: '', sectionId: '',
    careerId: '', categoryId: '', role: '', class: '', step: '',
    academicLevel: '', employmentStatus: '',
    gender: '', ageRange: '', isActive: ''
  });

  const [pagination, setPagination] = useState({ page: 1, limit: 15 });
  const [sort, setSort] = useState({ field: 'name', order: 'asc' });

  const [results, setResults] = useState([]);
  const [totalItems, setTotalItems] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [stats, setStats] = useState(null);

  const [isLoadingData, setIsLoadingData] = useState(false);
  const [isLoadingStats, setIsLoadingStats] = useState(false);

  const [confirmModal, setConfirmModal] = useState({ isOpen: false, empId: null });
  const [fullScreenPhoto, setFullScreenPhoto] = useState(null);

  const loadData = useCallback(async () => {
    setIsLoadingData(true);
    try {
      const res = await fetchEmployees(employees, orgData, filters, pagination, sort);
      setResults(res.data);
      setTotalItems(res.total);
      setTotalPages(res.totalPages);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoadingData(false);
    }
  }, [employees, orgData, filters, pagination, sort]);

  const loadStats = useCallback(async () => {
    setIsLoadingStats(true);
    try {
      const resStats = await getEmployeeStats(employees, orgData, filters);
      setStats(resStats);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoadingStats(false);
    }
  }, [employees, orgData, filters]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  useEffect(() => {
    loadStats();
    // Reiniciar para página 1 sempre que os filtros mudarem
    setPagination(prev => ({ ...prev, page: 1 }));
  }, [filters, loadStats]);

  const handleSort = (field) => {
    setSort(prev => {
      if (prev.field === field) return { field, order: prev.order === 'asc' ? 'desc' : 'asc' };
      return { field, order: 'asc' };
    });
  };

  const getName = (list, id) => list.find(item => item.id === id)?.name || '-';

  const exportExcel = async () => {
    // Obter todos sem paginação
    const res = await fetchEmployees(employees, orgData, filters, { page: 1, limit: 999999 }, sort);
    const exportData = res.data.map(emp => ({
      'NIB': emp.nip,
      'Nome': emp.name,
      'Género': emp.gender === 'M' ? 'Masculino' : (emp.gender === 'F' ? 'Feminino' : ''),
      'Carreira': getName(data.careers || [], emp.careerId),
      'Categoria': getName(data.categories, emp.categoryId),
      'Direcção': getName(data.directorates, emp.directorateId),
      'Departamento': getName(data.departments, emp.departmentId),
      'Repartição': getName(data.divisions, emp.divisionId),
      'Secção': getName(data.sections, emp.sectionId),
      'Estado': emp.isActive ? 'Ativo' : 'Inativo',
      'Data de Ingresso': emp.admissionDate || ''
    }));

    const worksheet = XLSX.utils.json_to_sheet(exportData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Funcionários");
    const dateStr = new Date().toLocaleDateString('pt-PT').replace(/\//g, '-');
    XLSX.writeFile(workbook, `Lista_Funcionarios_${dateStr}.xlsx`);
  };

  const exportPDF = async () => {
    const res = await fetchEmployees(employees, orgData, filters, { page: 1, limit: 999999 }, sort);
    const doc = new jsPDF('landscape');
    
    doc.setFontSize(16);
    doc.text('Listagem de Funcionários', 14, 15);
    doc.setFontSize(10);
    doc.text(`Total: ${res.total} | Data: ${new Date().toLocaleDateString()}`, 14, 22);

    const tableColumn = ["NIB", "Nome", "Género", "Carreira", "Direcção", "Estado"];
    const tableRows = [];

    res.data.forEach(emp => {
      const rowData = [
        emp.nip,
        emp.name,
        emp.gender,
        getName(data.careers || [], emp.careerId),
        getName(data.directorates, emp.directorateId),
        emp.isActive ? 'Ativo' : 'Inativo'
      ];
      tableRows.push(rowData);
    });

    doc.autoTable({
      head: [tableColumn],
      body: tableRows,
      startY: 28,
      styles: { fontSize: 8 },
      headStyles: { fillColor: [44, 62, 80] }
    });

    const dateStr = new Date().toLocaleDateString('pt-PT').replace(/\//g, '-');
    doc.save(`Funcionarios_${dateStr}.pdf`);
  };

  const printFicha = (emp) => {
    const processes = getProcessesByEmployee(emp.id);
    let disciplinaryHtml = '';
    
    if (processes.length === 0) {
      disciplinaryHtml = '<p style="font-size:14px; color:#718096; font-style:italic;">Sem registo de processo disciplinar.</p>';
    } else {
      disciplinaryHtml = `
        <table style="width:100%; border-collapse:collapse; margin-top:10px; font-size:13px;">
          <thead>
            <tr>
              <th style="border-bottom:2px solid #e2e8f0; padding:8px; text-align:left;">Nº Processo</th>
              <th style="border-bottom:2px solid #e2e8f0; padding:8px; text-align:left;">Tipo</th>
              <th style="border-bottom:2px solid #e2e8f0; padding:8px; text-align:left;">Estado</th>
              <th style="border-bottom:2px solid #e2e8f0; padding:8px; text-align:left;">Data Infração</th>
            </tr>
          </thead>
          <tbody>
            ${processes.map(p => `
              <tr>
                <td style="border-bottom:1px solid #e2e8f0; padding:8px;"><strong>${p.processNumber || '-'}</strong></td>
                <td style="border-bottom:1px solid #e2e8f0; padding:8px;">${p.type || '-'}</td>
                <td style="border-bottom:1px solid #e2e8f0; padding:8px;">${p.status || '-'}</td>
                <td style="border-bottom:1px solid #e2e8f0; padding:8px;">${p.infractionDate || '-'}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      `;
    }

    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
      <html>
        <head>
          <title>Ficha do Funcionário</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 40px; color: #333; }
            h1 { border-bottom: 2px solid #2c3e50; padding-bottom: 10px; color: #2c3e50; }
            .section { margin-top: 30px; }
            .section h3 { background-color: #f8fafc; padding: 10px; border-left: 4px solid #3182ce; }
            .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-top: 15px; }
            .item { margin-bottom: 10px; }
            .label { font-weight: bold; color: #718096; font-size: 12px; text-transform: uppercase; }
            .value { font-size: 14px; margin-top: 4px; }
            .header-flex { display: flex; align-items: flex-start; justify-content: space-between; gap: 30px; }
            .photo-box { width: 120px; height: 120px; border: 2px solid #e2e8f0; border-radius: 8px; object-fit: cover; }
          </style>
        </head>
        <body>
          <h1>Ficha Individual de Funcionário</h1>
          
          <div class="section header-flex">
            <div style="flex: 1;">
              <h3>Identificação</h3>
              <div class="grid">
                <div class="item"><div class="label">Nome Completo</div><div class="value">${emp.name || '-'}</div></div>
                <div class="item"><div class="label">NIB</div><div class="value">${emp.nip || '-'}</div></div>
                <div class="item"><div class="label">Nº de BI</div><div class="value">${emp.bi || '-'}</div></div>
                <div class="item"><div class="label">Data de Nascimento</div><div class="value">${emp.dob || '-'}</div></div>
                <div class="item"><div class="label">Género</div><div class="value">${emp.gender || '-'}</div></div>
                <div class="item"><div class="label">Nacionalidade</div><div class="value">${emp.nationality || '-'}</div></div>
              </div>
            </div>
            <div>
              ${emp.photo ? `<img src="${emp.photo}" class="photo-box" alt="Foto do Funcionário" />` : '<div class="photo-box" style="display:flex; align-items:center; justify-content:center; background:#f8fafc; color:#a0aec0; font-size:12px; text-align:center;">Sem Foto</div>'}
            </div>
          </div>

          <div class="section">
            <h3>Profissional</h3>
            <div class="grid">
              <div class="item"><div class="label">Carreira</div><div class="value">${getName(data.careers || [], emp.careerId)}</div></div>
              <div class="item"><div class="label">Categoria Funcional</div><div class="value">${getName(data.categories, emp.categoryId)}</div></div>
              <div class="item"><div class="label">Cargo</div><div class="value">${emp.role || '-'}</div></div>
              <div class="item"><div class="label">Nível Académico</div><div class="value">${emp.academicLevel || '-'}</div></div>
              <div class="item"><div class="label">Situação Laboral</div><div class="value">${emp.employmentStatus || '-'}</div></div>
              <div class="item"><div class="label">Data de Ingresso</div><div class="value">${emp.admissionDate || '-'}</div></div>
            </div>
          </div>

          <div class="section">
            <h3>Colocação</h3>
            <div class="grid">
              <div class="item"><div class="label">Direcção</div><div class="value">${getName(data.directorates, emp.directorateId)}</div></div>
              <div class="item"><div class="label">Departamento</div><div class="value">${getName(data.departments, emp.departmentId)}</div></div>
              <div class="item"><div class="label">Repartição</div><div class="value">${getName(data.divisions, emp.divisionId)}</div></div>
            </div>
          </div>

          <div class="section">
            <h3>Histórico Disciplinar</h3>
            ${disciplinaryHtml}
          </div>
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => { printWindow.print(); printWindow.close(); }, 500);
  };

  const SortIcon = ({ field }) => {
    if (sort.field !== field) return <span style={{opacity: 0.3}}>↕</span>;
    return <span>{sort.order === 'asc' ? '↑' : '↓'}</span>;
  };

  return (
    <div>
      <div style={styles.tabsContainer}>
        <button onClick={() => { setActiveTab('all'); setFilters({...filters, directorateId: '', departmentId: '', divisionId: '', sectionId: ''}); }} style={activeTab === 'all' ? styles.activeTab : styles.tab}>Todos os Funcionários</button>
        <button onClick={() => setActiveTab('org')} style={activeTab === 'org' ? styles.activeTab : styles.tab}>Por Estrutura Organizacional</button>
      </div>

      {activeTab === 'org' && (
        <div style={{...styles.orgFilterBanner, marginBottom: '24px'}}>
          <p style={{margin: '0 0 16px 0', fontSize: '14px', color: 'var(--color-primary)', fontWeight: '600'}}>Filtre os funcionários pela hierarquia da instituição:</p>
          <div style={{display: 'flex', gap: '16px', flexWrap: 'wrap'}}>
            <select name="directorateId" value={filters.directorateId} onChange={(e) => setFilters(p => ({...p, directorateId: e.target.value, departmentId: '', divisionId: '', sectionId: ''}))} style={styles.filterSelect}>
              <option value="">Selecione a Direcção...</option>
              {data.directorates.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
            </select>
            <select name="departmentId" value={filters.departmentId} onChange={(e) => setFilters(p => ({...p, departmentId: e.target.value, divisionId: '', sectionId: ''}))} style={styles.filterSelect} disabled={!filters.directorateId}>
              <option value="">Selecione o Departamento...</option>
              {data.departments.filter(d => d.directorateId === filters.directorateId).map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
            </select>
            <select name="divisionId" value={filters.divisionId} onChange={(e) => setFilters(p => ({...p, divisionId: e.target.value, sectionId: ''}))} style={styles.filterSelect} disabled={!filters.departmentId}>
              <option value="">Selecione a Repartição...</option>
              {data.divisions.filter(d => d.departmentId === filters.departmentId).map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
            </select>
          </div>
        </div>
      )}

      {/* Estatísticas */}
      <EmployeeStats stats={stats} isLoading={isLoadingStats} />

      {/* Ferramentas e Filtros */}
      <div style={styles.toolbar}>
        <div style={styles.searchBox}>
          <input 
            type="text" 
            placeholder="Pesquisar por Nome ou NIB..." 
            value={filters.searchTerm}
            onChange={(e) => setFilters(p => ({...p, searchTerm: e.target.value}))}
            style={styles.searchInput}
          />
        </div>
        <div style={styles.actions}>
          <button onClick={exportExcel} style={styles.btnAction}>Excel</button>
          <button onClick={exportPDF} style={styles.btnAction}>PDF</button>
          <button onClick={() => window.print()} style={styles.btnAction}>Imprimir Lista</button>
        </div>
      </div>

      <AdvancedFilters filters={filters} setFilters={setFilters} orgData={orgData} />

      {/* Tabela de Resultados */}
      <div style={styles.tableContainer}>
        {isLoadingData ? (
          <div style={{padding: '40px', textAlign: 'center', color: 'var(--color-text-muted)'}}>A carregar dados...</div>
        ) : (
          <table style={styles.table}>
            <thead>
              <tr>
                <th style={{...styles.th, cursor: 'pointer'}} onClick={() => handleSort('nip')}>NIB <SortIcon field="nip" /></th>
                <th style={{...styles.th, cursor: 'pointer'}} onClick={() => handleSort('name')}>Nome <SortIcon field="name" /></th>
                <th style={{...styles.th, cursor: 'pointer'}} onClick={() => handleSort('gender')}>G. <SortIcon field="gender" /></th>
                <th style={styles.th}>Carreira / Categoria</th>
                <th style={styles.th}>Direcção / Departamento</th>
                <th style={styles.th}>Estado</th>
                <th style={styles.th}>Ações</th>
              </tr>
            </thead>
            <tbody>
              {results.length === 0 ? (
                <tr>
                  <td colSpan="7" style={styles.empty}>Nenhum funcionário encontrado.</td>
                </tr>
              ) : (
                results.map(emp => (
                  <tr key={emp.id} style={styles.tr}>
                    <td style={styles.td}>
                      <div style={{display: 'flex', alignItems: 'center', gap: '12px'}}>
                        {emp.photo ? (
                          <img src={emp.photo} alt="avatar" style={{width: '32px', height: '32px', borderRadius: '50%', objectFit: 'cover', border: '1px solid var(--color-border)', cursor: 'pointer'}} onClick={() => setFullScreenPhoto(emp.photo)} title="Ver foto em FHD" />
                        ) : (
                          <div style={{width: '32px', height: '32px', borderRadius: '50%', backgroundColor: 'var(--color-bg-card)', border: '1px solid var(--color-border)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '14px'}}>👤</div>
                        )}
                        <strong>{emp.nip}</strong>
                      </div>
                    </td>
                    <td style={styles.td}>{emp.name}</td>
                    <td style={styles.td}>{emp.gender || '-'}</td>
                    <td style={styles.td}>
                      <div style={{fontSize: '13px'}}>{getName(data.careers || [], emp.careerId)}</div>
                      <div style={{fontSize: '11px', color: 'var(--color-text-muted)'}}>{getName(data.categories, emp.categoryId)}</div>
                    </td>
                    <td style={styles.td}>
                      <div style={{fontSize: '13px'}}>{getName(data.directorates, emp.directorateId)}</div>
                      <div style={{fontSize: '11px', color: 'var(--color-text-muted)'}}>{getName(data.departments, emp.departmentId)}</div>
                    </td>
                    <td style={styles.td}>
                      <span style={emp.isActive ? styles.badgeActive : styles.badgeInactive}>
                        {emp.isActive ? 'Ativo' : 'Inativo'}
                      </span>
                    </td>
                    <td style={styles.tdActions}>
                      <button onClick={() => printFicha(emp)} style={styles.btnIcon} title="Ficha Individual">🖨️</button>
                      <button onClick={() => onEdit(emp.id)} style={styles.btnIcon} title="Editar">✎</button>
                      <button onClick={() => setConfirmModal({ isOpen: true, empId: emp.id })} style={{...styles.btnIcon, color: '#e53e3e'}} title="Apagar">🗑</button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        )}
      </div>

      {/* Controlos de Paginação */}
      {!isLoadingData && totalPages > 1 && (
        <div style={styles.pagination}>
          <span style={{fontSize: '13px', color: 'var(--color-text-muted)'}}>Página {pagination.page} de {totalPages}</span>
          <div style={{display: 'flex', gap: '8px'}}>
            <button 
              disabled={pagination.page === 1}
              onClick={() => setPagination(p => ({...p, page: p.page - 1}))}
              style={styles.pageBtn}
            >Anterior</button>
            <button 
              disabled={pagination.page === totalPages}
              onClick={() => setPagination(p => ({...p, page: p.page + 1}))}
              style={styles.pageBtn}
            >Próxima</button>
          </div>
        </div>
      )}

      <ConfirmModal
        isOpen={confirmModal.isOpen}
        title="Confirmar Eliminação"
        message="Apagar funcionário definitivamente?"
        isDestructive={true}
        onConfirm={() => {
          onDelete(confirmModal.empId);
          setConfirmModal({ isOpen: false, empId: null });
        }}
        onCancel={() => setConfirmModal({ isOpen: false, empId: null })}
      />

      {fullScreenPhoto && (
        <div style={styles.fullscreenOverlay} onClick={() => setFullScreenPhoto(null)}>
          <img src={fullScreenPhoto} style={styles.fullscreenImage} alt="Fullscreen FHD" />
          <button style={styles.closeFullscreenBtn} onClick={(e) => { e.stopPropagation(); setFullScreenPhoto(null); }}>✕</button>
        </div>
      )}
    </div>
  );
}

const styles = {
  tabsContainer: { display: 'flex', gap: '4px', marginBottom: '24px', borderBottom: '1px solid var(--color-border)', flexWrap: 'wrap' },
  tab: { padding: '12px 20px', background: 'transparent', border: 'none', color: 'var(--color-text-muted)', fontSize: '14px', fontWeight: '600', cursor: 'pointer', borderBottom: '3px solid transparent' },
  activeTab: { padding: '12px 20px', background: 'transparent', border: 'none', color: 'var(--color-primary)', fontSize: '14px', fontWeight: '600', cursor: 'pointer', borderBottom: '3px solid var(--color-primary)' },
  orgFilterBanner: { backgroundColor: 'rgba(49, 130, 206, 0.05)', border: '1px solid rgba(49, 130, 206, 0.2)', padding: '20px', borderRadius: '8px' },
  filterSelect: { padding: '10px 12px', borderRadius: '6px', border: '1px solid var(--color-border)', backgroundColor: 'var(--color-bg-base)', color: 'var(--color-text-base)', fontSize: '13px', minWidth: '220px' },
  toolbar: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px', flexWrap: 'wrap', gap: '16px' },
  searchBox: { flex: 1, minWidth: '300px' },
  searchInput: { width: '100%', padding: '12px 16px', borderRadius: '8px', border: '1px solid var(--color-border)', backgroundColor: 'var(--color-bg-base)', color: 'var(--color-text-base)', fontSize: '14px' },
  actions: { display: 'flex', gap: '12px' },
  btnAction: { padding: '10px 16px', backgroundColor: 'var(--color-bg-base)', color: 'var(--color-text-base)', border: '1px solid var(--color-border)', borderRadius: '6px', fontSize: '13px', fontWeight: '600', cursor: 'pointer' },
  tableContainer: { overflowX: 'auto', backgroundColor: 'var(--color-bg-base)', borderRadius: '8px', border: '1px solid var(--color-border)' },
  table: { width: '100%', borderCollapse: 'collapse', fontSize: '14px' },
  th: { textAlign: 'left', padding: '14px 16px', borderBottom: '2px solid var(--color-border)', color: 'var(--color-text-muted)', fontWeight: '600' },
  tr: { borderBottom: '1px solid var(--color-border)' },
  td: { padding: '14px 16px', color: 'var(--color-text-base)' },
  tdActions: { padding: '14px 16px', display: 'flex', gap: '12px' },
  btnIcon: { background: 'transparent', border: 'none', cursor: 'pointer', fontSize: '16px', color: 'var(--color-text-muted)' },
  empty: { textAlign: 'center', padding: '40px', color: 'var(--color-text-muted)', fontStyle: 'italic' },
  badgeActive: { backgroundColor: 'rgba(72, 187, 120, 0.15)', color: '#2f855a', padding: '4px 8px', borderRadius: '12px', fontSize: '12px', fontWeight: '600' },
  badgeInactive: { backgroundColor: 'rgba(160, 174, 192, 0.15)', color: '#718096', padding: '4px 8px', borderRadius: '12px', fontSize: '12px', fontWeight: '600' },
  pagination: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '20px', padding: '16px', backgroundColor: 'var(--color-bg-base)', borderRadius: '8px', border: '1px solid var(--color-border)' },
  pageBtn: { padding: '8px 16px', backgroundColor: 'var(--color-bg-card)', border: '1px solid var(--color-border)', borderRadius: '6px', cursor: 'pointer', fontWeight: '600', fontSize: '13px' },
  fullscreenOverlay: { position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.85)', zIndex: 9999, display: 'flex', justifyContent: 'center', alignItems: 'center', animation: 'fadeIn 0.2s ease' },
  fullscreenImage: { maxHeight: '90vh', maxWidth: '90vw', borderRadius: '8px', objectFit: 'contain', boxShadow: '0 10px 25px rgba(0,0,0,0.5)' },
  closeFullscreenBtn: { position: 'absolute', top: '20px', right: '30px', background: 'transparent', border: 'none', color: '#fff', fontSize: '30px', cursor: 'pointer', opacity: 0.8 }
};
